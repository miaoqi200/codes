from tqdm import tqdm
import ujson as json

docred_rel2id = json.load(open('meta/rel2id.json', 'r'))
cdr_rel2id = {'1:NR:2': 0, '1:CID:2': 1}
gda_rel2id = {'1:NR:2': 0, '1:GDA:2': 1}
docred_ev2id={}
for i in range(0,30):
    docred_ev2id[i]=i

def chunks(l, n):
    res = []
    for i in range(0, len(l), n):
        assert len(l[i:i + n]) == n
        res += [l[i:i + n]]
    return res


def read_docred(file_in, tokenizer, max_seq_length=1024):
    i_line = 0
    pos_samples = 0
    neg_samples = 0
    features = []
    if file_in == "":
        return None
    with open(file_in, "r") as fh:
        data = json.load(fh)

    for sample in tqdm(data, desc="Example"):
        sents = []
        sent_map = []

        sents_pos = []
        entities = sample['vertexSet']
        entity_start, entity_end = [], []
        for entity in entities:
            for mention in entity:
                sent_id = mention["sent_id"]
                pos = mention["pos"]
                entity_start.append((sent_id, pos[0],))
                entity_end.append((sent_id, pos[1] - 1,))
        nn=0
        for i_s, sent in enumerate(sample['sents']):


            nn=len(sents)
            new_map = {}
            for i_t, token in enumerate(sent):
                tokens_wordpiece = tokenizer.tokenize(token)
                if (i_s, i_t) in entity_start:
                    tokens_wordpiece = ["*"] + tokens_wordpiece
                if (i_s, i_t) in entity_end:
                    tokens_wordpiece = tokens_wordpiece + ["*"]
                new_map[i_t] = len(sents)
                sents.extend(tokens_wordpiece)
            sents_pos.append([nn, len(sents)])
            new_map[i_t + 1] = len(sents)
            sent_map.append(new_map)

        train_triple = {}
        evidence_triple ={}
        if "labels" in sample:
            for label in sample['labels']:
                evidence = label['evidence']
                r = int(docred_rel2id[label['r']])
                if (label['h'], label['t']) not in train_triple:
                    train_triple[(label['h'], label['t'])] = [
                        {'relation': r, 'evidence': evidence}]
                else:
                    train_triple[(label['h'], label['t'])].append(
                        {'relation': r, 'evidence': evidence})

                if len(evidence)==0:
                    evidence_triple[(label['h'], label['t'])] = [
                        {'evidence': -1}]
                for ui in evidence:
                    if (label['h'], label['t']) not in evidence_triple:
                        evidence_triple[(label['h'], label['t'])] = [
                            {'evidence': ui}]
                    else:
                        evidence_triple[(label['h'], label['t'])].append(
                            {'evidence': ui})

        entity_pos = []
        for e in entities:
            entity_pos.append([])
            for m in e:
                start = sent_map[m["sent_id"]][m["pos"][0]]
                end = sent_map[m["sent_id"]][m["pos"][1]]
                entity_pos[-1].append((start, end,))

        relations, hts1,hts2,evrelations = [], [],{},[]
        for h, t in train_triple.keys():
            relation = [0] * len(docred_rel2id)
            evrelation =[0]* len(docred_ev2id)
            f=0
            for mention in train_triple[h, t]:
                relation[mention["relation"]] = 1

                evidence = mention["evidence"]
                if evidence or f:
                    f=1
                    evrelation[0]=0
                    for yty in mention["evidence"]:
                        evrelation[yty]=1
                else:
                    evrelation[0]=1
            relations.append(relation)
            evrelations.append(evrelation)
            hts1.append([h, t])
            # hts2[[h, t]] = evidence
            pos_samples += 1




        for h in range(len(entities)):
            for t in range(len(entities)):
                if h != t and [h, t] not in hts1:
                    relation = [1] + [0] * (len(docred_rel2id) - 1)
                    evrelation = [0] * (len(docred_ev2id) )
                    relations.append(relation)
                    evrelations.append(evrelation)
                    hts1.append([h, t])
                    neg_samples += 1



        sents = sents[:max_seq_length - 2]
        input_ids = tokenizer.convert_tokens_to_ids(sents)
        input_ids = tokenizer.build_inputs_with_special_tokens(input_ids)

        i_line += 1
        feature = {'input_ids': input_ids,
                   'entity_pos': entity_pos,
                   'labels': relations,
                   'hts': hts1,
                   'title': sample['title'],
                   'evlabels': evrelations,
                   'sents_pos':sents_pos
                   }
        features.append(feature)

    print("# of documents {}.".format(i_line))
    print("# of positive examples {}.".format(pos_samples))
    print("# of negative examples {}.".format(neg_samples))
    return features

