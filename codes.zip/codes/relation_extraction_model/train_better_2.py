import argparse
import os
from tqdm import tqdm
import numpy as np
import torch
# import apex
# from apex import amp
import ujson as json
from torch.utils.data import DataLoader
from transformers import AutoConfig, AutoModel, AutoTokenizer
from transformers.optimization import AdamW, get_linear_schedule_with_warmup
from model2 import DocREModel
from utils2 import set_seed, collate_fn
from prepro2 import read_docred
from evaluation import to_official,  official_evaluate,show_official_evaluate
# import wandb
from datetime import datetime

# 32:
# 4.192e-06
# 3.794e-06
# 3.396e-06
# 3.041e-06
# 2.997e-06
# 2.599e-06
# 2.201e-06
# 1.803e-06
# 1.521730470461698e-06
# 1.4042146357009122e-06
# 1.0058558737999442e-06
# 6.074971118989762e-07
# 2.0913834999800823e-07
# 1.99179380950484e-09


def train(args, model, train_features, dev_features, test_features):
    def finetune(features, optimizer, num_epoch, num_steps):
        # Loss = torch.nn.BCELoss()
        best_score = -1
        train_dataloader = DataLoader(features, batch_size=args.train_batch_size, shuffle=True, collate_fn=collate_fn, drop_last=True)
        train_iterator = range(int(num_epoch))
        total_steps = int(len(train_dataloader) * num_epoch // args.gradient_accumulation_steps)
        warmup_steps = int(total_steps * args.warmup_ratio)
        # scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=warmup_steps, num_training_steps=total_steps)
        # scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min', factor=0.5,   min_lr=1e-10,
        #                                                        patience=100,eps=1e-08)
        scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, 4, eta_min=0, last_epoch=-1)
        print("Total steps: {}".format(total_steps))
        print("Warmup steps: {}".format(warmup_steps))
        for epoch in train_iterator:
            model.zero_grad()
            for step, batch in enumerate(tqdm(train_dataloader)):
                model.train()
                inputs = {'input_ids': batch[0].to(args.device),
                          'attention_mask': batch[1].to(args.device),
                          'labels': batch[2],
                          'entity_pos': batch[3],
                          'hts': batch[4],
                          'evlabels': batch[5],
                          'sents_pos': batch[6]
                          }
                outputs = model(**inputs)

                loss = outputs[0] / args.gradient_accumulation_steps
                # with amp.scale_loss(loss, optimizer) as scaled_loss:
                loss.backward()
                if step % args.gradient_accumulation_steps == 0:
                    # if args.max_grad_norm > 0:
                    #     torch.nn.utils.clip_grad_norm_(amp.master_params(optimizer), args.max_grad_norm)
                    optimizer.step()
                    scheduler.step()
                    model.zero_grad()
                    num_steps += 1
                # wandb.log({"loss": loss.item()}, step=num_steps)
                # if epoch<=10:
                #     continue
                if (step + 1) == len(train_dataloader) - 1 or (args.evaluation_steps > 0 and num_steps % args.evaluation_steps == 0 and step % args.gradient_accumulation_steps == 0):
                    dev_score, dev_output = evaluate(args, model, dev_features, tag="dev")
                    # wandb.log(dev_output, step=num_steps)

                    dt = datetime.now()

                    if dev_score > best_score:
                        best_score = dev_score
                        # pred = report(args, model, test_features)
                        # with open("result.json", "w") as fh:
                        #     json.dump(pred, fh)
                        if args.save_path != "":
                            torch.save(model.state_dict(), args.save_path)
        return num_steps

    new_layer = ["extractor", "bilinear"]
    optimizer_grouped_parameters = [
        {"params": [p for n, p in model.named_parameters() if not any(nd in n for nd in new_layer)], },
        {"params": [p for n, p in model.named_parameters() if any(nd in n for nd in new_layer)], "lr": 1e-5},
    ]

    optimizer = AdamW(optimizer_grouped_parameters, lr=args.learning_rate, eps=args.adam_epsilon)
    # model, optimizer = amp.initialize(model, optimizer, opt_level="O1", verbosity=0)
    num_steps = 0
    set_seed(args)
    model.zero_grad()
    finetune(train_features, optimizer, args.num_train_epochs, num_steps)


def evaluate(args, model, features, tag="dev"):

    dataloader = DataLoader(features, batch_size=args.test_batch_size, shuffle=False, collate_fn=collate_fn, drop_last=False)
    preds = []
    for batch in dataloader:
        model.eval()

        inputs = {'input_ids': batch[0].to(args.device),
                  'attention_mask': batch[1].to(args.device),
                  'entity_pos': batch[3],
                  'hts': batch[4],
                  'evlabels': batch[5],
                  'sents_pos': batch[6]
                  }

        with torch.no_grad():
            pred, *_ = model(**inputs)
            pred = pred.cpu().numpy()
            pred[np.isnan(pred)] = 0
            preds.append(pred)

    preds = np.concatenate(preds, axis=0).astype(np.float32)
    ans = to_official(preds, features)
    best_f1 = 0.00000001
    best_f1_ign = 0.00000001
    if len(ans) > 0:
        best_f1, _, best_f1_ign, _ = official_evaluate(ans, args.data_dir)
    output = {
        tag + "_F1": best_f1 * 100,
        tag + "_F1_ign": best_f1_ign * 100,
    }
    return best_f1, output


def report(args, model, features):

    dataloader = DataLoader(features, batch_size=args.test_batch_size, shuffle=False, collate_fn=collate_fn, drop_last=False)
    preds = []
    for batch in dataloader:
        model.eval()

        inputs = {'input_ids': batch[0].to(args.device),
                  'attention_mask': batch[1].to(args.device),
                  'entity_pos': batch[3],
                  'hts': batch[4],
                  'evlabels': batch[5],
                  'sents_pos': batch[6]
                  }

        with torch.no_grad():
            pred, *_ = model(**inputs)
            pred = pred.cpu().numpy()
            pred[np.isnan(pred)] = 0
            preds.append(pred)

    preds = np.concatenate(preds, axis=0).astype(np.float32)
    preds = to_official(preds, features)
    return preds


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", default="./dataset/docred", type=str)


    parser.add_argument("--transformer_type", default="xlnet", type=str)
    parser.add_argument("--model_name_or_path", default="./xlnet-base-cased", type=str)
    parser.add_argument("--save_path", default="xlnet_best1.ph", type=str)

    # parser.add_argument("--transformer_type", default="bert", type=str)
    # parser.add_argument("--model_name_or_path", default="./dataset/bert-base-cased", type=str)
    # parser.add_argument("--save_path", default="bert.ph", type=str)

    parser.add_argument("--train_file", default="train_annotated.json", type=str)
    parser.add_argument("--dev_file", default="dev.json", type=str)
    parser.add_argument("--test_file", default="test.json", type=str)

    parser.add_argument("--load_path", default="xlnet_9.ph", type=str)

    parser.add_argument("--config_name", default="", type=str,
                        help="Pretrained config name or path if not the same as model_name")
    parser.add_argument("--tokenizer_name", default="", type=str,
                        help="Pretrained tokenizer name or path if not the same as model_name")
    parser.add_argument("--max_seq_length", default=1024, type=int,
                        help="The maximum total input sequence length after tokenization. Sequences longer "
                             "than this will be truncated, sequences shorter will be padded.")

    # parser.add_argument("--train_batch_size", default=4, type=int,
    #                     help="Batch size for training.")
    parser.add_argument("--train_batch_size", default=4, type=int,
                        help="Batch size for training.")
    parser.add_argument("--test_batch_size", default=15 , type=int,
                        help="Batch size for testing.")
    parser.add_argument("--gradient_accumulation_steps", default=1, type=int,
                        help="Number of updates steps to accumulate before performing a backward/update pass.")
    parser.add_argument("--num_labels", default=4, type=int,
                        help="Max number of labels in prediction.")
    parser.add_argument("--learning_rate", default=2e-6, type=float,
                        help="The initial learning rate for Adam.")
    parser.add_argument("--adam_epsilon", default=1e-6, type=float,
                        help="Epsilon for Adam optimizer.")
    parser.add_argument("--max_grad_norm", default=1.0, type=float,
                        help="Max gradient norm.")
    parser.add_argument("--warmup_ratio", default=0.06, type=float,
                        help="Warm up ratio for Adam.")
    parser.add_argument("--num_train_epochs", default=70.0, type=float,
                        help="Total number of training epochs to perform.")
    parser.add_argument("--evaluation_steps", default=200, type=int,
                        help="Number of training steps between evaluations.")
    parser.add_argument("--seed", type=int, default=21344,
                        help="random seed for initialization")
    # parser.add_argument("--seed", type=int, default=66,
    #                     help="random seed for initialization")
    parser.add_argument("--num_class", type=int, default=97,
                        help="Number of relation types in dataset.")

    args = parser.parse_args()
    # wandb.init(project="DocRED")

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    args.n_gpu = torch.cuda.device_count()
    args.device = device

    config = AutoConfig.from_pretrained(
        args.config_name if args.config_name else args.model_name_or_path,
        num_labels=args.num_class,
    )
    tokenizer = AutoTokenizer.from_pretrained(
        args.tokenizer_name if args.tokenizer_name else args.model_name_or_path,
    )

    read = read_docred



    try:
        # print( iuuioin)
        train_features = json.load(open(args.transformer_type+"train_features_ev.json_features"))
        dev_features = json.load(open(args.transformer_type+"dev_features_ev.json_features"))
        test_features = json.load(open(args.transformer_type+"test_features_ev.json_features"))
    except:
        train_file = os.path.join(args.data_dir, args.train_file)
        dev_file = os.path.join(args.data_dir, args.dev_file)
        test_file = os.path.join(args.data_dir, args.test_file)
        train_features = read(train_file, tokenizer, max_seq_length=args.max_seq_length)
        dev_features = read(dev_file, tokenizer, max_seq_length=args.max_seq_length)
        test_features = read(test_file, tokenizer, max_seq_length=args.max_seq_length)
        json.dump(train_features,open(args.transformer_type+"train_features_ev.json_features","w",encoding="utf8"))
        json.dump(dev_features, open(args.transformer_type+"dev_features_ev.json_features", "w", encoding="utf8"))
        json.dump(test_features, open(args.transformer_type+"test_features_ev.json_features", "w", encoding="utf8"))


    model = AutoModel.from_pretrained(
        args.model_name_or_path,
        from_tf=bool(".ckpt" in args.model_name_or_path),
        config=config
    )

    config.cls_token_id = tokenizer.cls_token_id
    config.sep_token_id = tokenizer.sep_token_id
    config.transformer_type = args.transformer_type

    set_seed(args)
    model = DocREModel(config, model, num_labels=args.num_labels)
    model.to(0)

    # if args.load_path == "":  # Training
    model.load_state_dict(torch.load(args.load_path),strict=False)
    train(args, model, train_features, dev_features, test_features)
    # else:  # Testing
    #     # model = amp.initialize(model, opt_level="O1", verbosity=0)
    #     model.load_state_dict(torch.load(args.load_path))
    #     dev_score, dev_output = evaluate(args, model, dev_features, tag="dev")
    #     print(dev_output)
    #     pred = report(args, model, test_features)
    #     with open("result.json", "w") as fh:
    #         json.dump(pred, fh)

def GPURUN(memory=20000, choosegpu=[]):
        if choosegpu is None:
            choosegpu = []
        import time
        import subprocess
        while 1:
            start_time = time.time()

            result = subprocess.check_output(
                [
                    'nvidia-smi', '--query-gpu=memory.free,utilization.gpu',
                    '--format=csv,nounits,noheader'
                ], encoding='utf-8')
            gpu_info = [eval(x) for x in result.strip().split('\n')]
            gpu_info = dict(zip(range(len(gpu_info)), gpu_info))
            sorted_gpu_info = sorted(gpu_info.items(), key=lambda kv: kv[1][0], reverse=True)
            sorted_gpu_info = sorted(sorted_gpu_info, key=lambda kv: kv[1][1])
            # print(f'gpu_id, (mem_left, util): {sorted_gpu_info}')
            for gpu_id, (mem_left, util) in sorted_gpu_info:
                if choosegpu == []:
                    if mem_left >= memory:
                        print(sorted_gpu_info)
                        return gpu_id
                else:
                    if mem_left >= memory and gpu_id in choosegpu:
                        print(sorted_gpu_info)
                        return gpu_id
if __name__ == "__main__":
    import os

    ChooseGPU = GPURUN(20000, [0, 1, 2, 3])
    os.environ['CUDA_VISIBLE_DEVICES'] = str(ChooseGPU)
    print(str(ChooseGPU))
    main()
