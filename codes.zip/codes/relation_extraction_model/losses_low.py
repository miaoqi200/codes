import torch
import torch.nn as nn
import torch.nn.functional as F
dingwei ={"P1376": 79, "P607": 27, "P136": 73, "P137": 63, "P131":  2, "P527": 11, "P1412": 38, "P206": 33, "P205": 77, "P449": 52, "P127": 34, "P123": 49, "P86": 66, "P840": 85, "P355": 72, "P737": 93, "P740": 84, "P190": 94, "P576": 71, "P749": 68, "P112": 65, "P118": 40, "P17": 1, "P19": 14, "P3373": 19, "P6": 42, "P276": 44, "P1001": 24, "P580": 62, "P582": 83, "P585": 64, "P463": 18, "P676": 87, "P674": 46, "P264": 10, "P108": 43, "P102": 17, "P25": 81, "P27": 3, "P26": 26, "P20": 37, "P22": 30, "Na": 0, "P807": 95, "P800": 51, "P279": 78, "P1336": 88, "P577": 5, "P570": 8, "P571": 15, "P178": 36, "P179": 55, "P272": 75, "P170": 35, "P171": 80, "P172": 76, "P175": 6, "P176": 67, "P39": 91, "P30": 21, "P31": 60, "P36": 70, "P37": 58, "P35": 54, "P400": 31, "P403": 61, "P361": 12, "P364": 74, "P569": 7, "P710": 41, "P1344": 32, "P488": 82, "P241": 59, "P162": 57, "P161": 9, "P166": 47, "P40": 20, "P1441": 23, "P156": 45, "P155": 39, "P150": 4, "P551": 90, "P706": 56, "P159": 29, "P495": 13, "P58": 53, "P194": 48, "P54": 16, "P57": 28, "P50": 22, "P1366": 86, "P1365": 92, "P937": 69, "P140": 50, "P69": 25, "P1198": 96, "P1056": 89}
needchangge=dict([('P17', 10276),
 ('P27', 4527),
 ('P131',  4388),
 ('P569',  2026),
 ('P150',   1716),
 ('P570',   1592),
 ('P577',  1483),
 ('P175',   1398),
 ('P19',  1035),
 ('P161', 942),
 ('P571', 927),
 ('P102', 873),
 ('P54', 818)])
changedingwei = {}
changedingwei2 = {}
pianzhi=0
for k,v in needchangge.items():
    if k in dingwei:
        changedingwei[k] = dingwei[k]
        changedingwei2[dingwei[k]]=k
        needchangge[k] =(needchangge[k]-800+pianzhi)/needchangge[k]







class ATLoss(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, logits, labels):
        # TH label
        th_label = torch.zeros_like(labels, dtype=torch.float).to(labels)
        for i in range(labels.shape[0]):
            for ii in changedingwei2:
                if labels[i][ii]==1:
                    suijishu = torch.rand(1)[0]
                    if suijishu<=needchangge[changedingwei2[ii]]:
                        labels[i][ii]=0
                        logits[i][ii]=0




        th_label[:, 0] = 1.0
        labels[:, 0] = 0.0

        p_mask = labels + th_label
        n_mask = 1 - labels

        # Rank positive classes to TH
        logit1 = logits - (1 - p_mask) * 1e30
        loss1 = -(F.log_softmax(logit1, dim=-1) * labels).sum(1)

        # Rank TH to negative classes
        logit2 = logits  -  (1 - n_mask) * 1e30
        loss2 = -(F.log_softmax(logit2, dim=-1) * th_label).sum(1)

        # Sum two parts
        loss = loss1 + 10*loss2
        loss = loss.mean()
        return loss

    def get_label(self, logits, num_labels=-1):
        th_logit = logits[:, 0].unsqueeze(1)
        output = torch.zeros_like(logits).to(logits)
        mask = (logits > th_logit)
        if num_labels > 0:
            top_v, _ = torch.topk(logits, num_labels, dim=1)
            top_v = top_v[:, -1]
            mask = (logits >= top_v.unsqueeze(1)) & mask
        output[mask] = 1.0
        output[:, 0] = (output.sum(1) == 0.).to(logits)
        return output
