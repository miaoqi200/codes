# bash scripts/train_bert.sh eider test hoi
#bash scripts/train_bert.sh eider test hoi
seed=66

ablation=eider
name=test
coref_method=hoi

eval_mode=dev_only

ensemble_mode=none
ensemble_ablation=none

evi_eval_mode=none

python train.py --data_dir ./dataset/docred \
--transformer_type bert \
--model_name_or_path bert-base-cased \
--train_file train_annotated.json \
--dev_file dev.json \
--test_file test.json \
--train_batch_size 4 \
--test_batch_size 8 \
--gradient_accumulation_steps 1 \
--num_labels 4 \
--learning_rate 5e-5 \
--max_grad_norm 1.0 \
--warmup_ratio 0.06 \
--num_train_epochs 30.0 \
--seed ${seed} \
--num_class 97 \
--evaluation_steps -1 \
--save_path chkpt/EIDER_bert_${ablation}_${name}_best.pt \
--ablation ${ablation} \
--name ${name} \
--feature_path saved_features \
--coref_method ${coref_method} \
--eval_mode ${eval_mode} \
--evi_eval_mode ${evi_eval_mode} \
--ensemble_mode ${ensemble_mode} \
--ensemble_ablation ${ensemble_ablation}
