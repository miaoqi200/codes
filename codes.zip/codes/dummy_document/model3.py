import torch
import torch.nn as nn
import torch.nn.functional as F
from opt_einsum import contract
from long_seq2 import process_long_input
from losses import ATLoss
import math

from IPython import embed
import numpy as np
from torch.nn.parameter import Parameter

INF = 1e8

class DocREModel(nn.Module):
    def __init__(self, config, model, ablation='atlop', max_sen_num=25, emb_size=768, block_size=64, num_labels=-1, att_size=128, b_hid_size=194):
        super().__init__()
        self.config = config
        self.model = model
        self.hidden_size = config.hidden_size
        self.evloss = nn.BCELoss()

        self.loss_fnt = ATLoss()


        self.max_sen_num = max_sen_num
        self.hidden_size = config.hidden_size
        self.loss_fnt = ATLoss()
        self.LayerNorm = torch.nn.LayerNorm(768)

        self.head_extractor = nn.Linear(2 * config.hidden_size, emb_size)
        self.tail_extractor = nn.Linear(2 * config.hidden_size, emb_size)
        self.bilinear = nn.Linear(emb_size * block_size, config.num_labels)

        self.emb_size = emb_size
        self.block_size = block_size
        self.num_labels = num_labels

        self.relu = torch.nn.ReLU()

        self.p1 = nn.Parameter(torch.randn(1, 768))
        self.p2 = nn.Parameter(torch.randn(1, 768))
        self.p3 = nn.Parameter(torch.randn(1, 768))
        self.l1 = nn.Linear(2 * 768, 768)
        self.l2 = nn.Linear(2 * 768, 768)
        self.l3 = nn.Linear(2 * 768, 768)
        self.drppout = nn.Dropout(0.2)
        self.para = torch.nn.Parameter(torch.tensor([0.5]))

        self.weight1 = nn.Parameter(torch.randn(1, 768))
        self.weight2 = nn.Parameter(torch.randn(1, 768))
        self.weight3 = nn.Parameter(torch.randn(1, 768))

    def encode(self, input_ids, attention_mask):
        config = self.config
        if config.transformer_type == "bert":
            start_tokens = [config.cls_token_id]
            end_tokens = [config.sep_token_id]
        elif config.transformer_type == "roberta":
            start_tokens = [config.cls_token_id]
            end_tokens = [config.sep_token_id, config.sep_token_id]
        sequence_output, attention = process_long_input(self.model, input_ids, attention_mask, [], [],config.transformer_type)
        return sequence_output, attention

    def new_get_hrt(self, sequence_output, attention, entity_pos, hts, _sents_pos):
        offset = 1 if self.config.transformer_type in ["bert", "roberta"] else 0
        n, h, _, c = attention.size()
        hss, tss, rss, atts, mask = [], [], [], [], []
        for i in range(len(entity_pos)):  
            mentions_token_pos = []
            all_entity_embs, entity_embs, entity_atts, entity_myatts = [], [], [], []
            my_entity_atts = []
            for e in entity_pos[i]:  

                if len(e) > 1:
                    e_emb, e_emb_new, e_att, mye_att = [], [], [], []
                    mentions_en_pos_bg = []

                    for start, end in e:  
                        if start + offset < c:  
                            
                            e_emb.append(sequence_output[i, start + offset])
                            e_emb_new.append(sequence_output[i, start + offset])  
                            mye_att.append(
                                attention[i, :, start + offset].mean(0))  
                            mentions_en_pos_bg.append(start + offset)
                            e_att.append(attention[i, :, start + offset])

                    if len(e_emb) > 0:  
                        e_emb = torch.logsumexp(torch.stack(e_emb, dim=0), dim=0)
                        
                        
                        e_emb_new = torch.stack(e_emb_new, dim=0)
                        e_att = torch.stack(e_att, dim=0).mean(0)
                        
                    else:
                        e_emb = torch.zeros(self.config.hidden_size).to(sequence_output)
                        e_emb_new = torch.zeros(1, self.config.hidden_size).to(sequence_output)
                        mye_att.append(torch.zeros(1, c)).to(attention)
                        e_att = torch.zeros(h, c).to(attention)
                else:
                    e_emb, e_emb_new, e_att, mye_att = [], [], [], []
                    mentions_en_pos_bg = []
                    start, end = e[0]
                    if start + offset < c:
                        e_emb = sequence_output[i, start + offset]
                        e_emb_new = sequence_output[i, start + offset].view(1, -1)
                        mentions_en_pos_bg.append(start + offset)
                        mye_att.append(attention[i, :, start + offset].mean(0))
                        e_att = attention[i, :, start + offset]
                    else:
                        e_emb = torch.zeros(self.config.hidden_size).to(sequence_output)
                        e_emb_new = torch.zeros(self.config.hidden_size).view(1, -1).to(sequence_output)
                        mentions_en_pos_bg.append(0)
                        mye_att.append(torch.zeros(1, c)).to(attention)
                        e_att = torch.zeros(h, c).to(attention)
                entity_embs.append(e_emb_new)
                entity_myatts.append(mye_att)
                mentions_token_pos.append(mentions_en_pos_bg)
                entity_atts.append(e_att)
                all_entity_embs.append(e_emb)

            
            hts_of_Sample_i = hts[i]  
            sample_i_mention_embings = entity_embs
            sample_i_mention_attention = entity_myatts
            mentions_token_pos = mentions_token_pos
            p_entity_embs = []
            q_entity_embs = []
            My_ht_att = []
            
            
            
            

            for pair_pq in hts_of_Sample_i:  
                p_eid, q_eid = pair_pq  
                M_p_pos = mentions_token_pos[p_eid]
                M_q_pos = mentions_token_pos[q_eid]
                M_p_emb = sample_i_mention_embings[p_eid]
                M_q_emb = sample_i_mention_embings[q_eid]
                M_p_attention = sample_i_mention_attention[p_eid]
                M_q_attention = sample_i_mention_attention[q_eid]

                
                p_attention_2_q = []  
                q_attention_2_p = []  
                for p_pos in range(
                        len(M_p_pos)):  
                    attiontionsum = 0
                    for q_pos in M_q_pos:
                        attiontionsum += math.exp(M_p_attention[p_pos][q_pos])
                    p_attention_2_q.append(math.log(attiontionsum))
                for q_pos in range(len(M_q_pos)):
                    attiontionsum = 0
                    for p_pos in M_p_pos:
                        attiontionsum += math.exp(M_q_attention[q_pos][p_pos])
                    q_attention_2_p.append(math.log(attiontionsum))
                
                p_attention_2_q = torch.nn.functional.softmax(torch.tensor(p_attention_2_q), dim=0).cuda(0)
                q_attention_2_p = torch.nn.functional.softmax(torch.tensor(q_attention_2_p), dim=0).cuda(0)

                roud_feeling_emb_p = p_attention_2_q.unsqueeze(0).mm(torch.stack(M_p_attention, dim=0)).view(
                    -1)  
                roud_feeling_emb_q = q_attention_2_p.unsqueeze(0).mm(torch.stack(M_q_attention, dim=0)).view(
                    -1)  
                my_ht_att = roud_feeling_emb_p * roud_feeling_emb_q
                my_ht_att = my_ht_att / (my_ht_att.sum() + 1e-5)
                My_ht_att.append(my_ht_att)
                my_ht_att_emb = my_ht_att.unsqueeze(0).mm(sequence_output[i]).view(-1)
                my_entity_atts.append(my_ht_att_emb)

                Epemb = p_attention_2_q.unsqueeze(0).mm(M_p_emb).view(-1)
                Eqemb = q_attention_2_p.unsqueeze(0).mm(M_q_emb).view(-1)
                p_entity_embs.append(Epemb)
                q_entity_embs.append(Eqemb)

                
                

            p_entity_embs = torch.stack(p_entity_embs, dim=0).cuda(0)  
            q_entity_embs = torch.stack(q_entity_embs, dim=0).cuda(0)  
            all_entity_embs = torch.stack(all_entity_embs, dim=0).cuda(0)
            entity_atts = torch.stack(entity_atts, dim=0).cuda(0)  
            My_ht_att = torch.stack(My_ht_att, dim=0).cuda(0)
            my_entity_atts = torch.stack(my_entity_atts, dim=0).cuda(0)

            ht_i = torch.LongTensor(hts[i]).to(sequence_output.device)
            hs_xi = p_entity_embs
            ts_xi = q_entity_embs
            hs = torch.index_select(all_entity_embs, 0, ht_i[:, 0])
            ts = torch.index_select(all_entity_embs, 0, ht_i[:, 1])

            h_att = torch.index_select(entity_atts, 0, ht_i[:, 0])
            t_att = torch.index_select(entity_atts, 0, ht_i[:, 1])
            ht_att = (h_att * t_att).mean(1)
            ht_att = ht_att / (ht_att.sum(1, keepdim=True) + 1e-5)

            pay_attention_sent1 = My_ht_att
            pay_attention_sent2 = ht_att
            pay_attention_sent = self.para * pay_attention_sent1 + (1 - self.para) * pay_attention_sent2
            if _sents_pos:
                daichuli = []
                Sents_pos_true = _sents_pos[i]
                for sent_fanwei in Sents_pos_true:
                    partmax = torch.max(pay_attention_sent[:, offset + sent_fanwei[0]:offset + sent_fanwei[1]],
                                        dim=1).values
                    partmean = torch.mean(pay_attention_sent[:, offset + sent_fanwei[0]:offset + sent_fanwei[1]], dim=1)
                    part = partmax + partmean
                    daichuli.append(part)
                daichuli = torch.stack(daichuli, dim=1)
                
                

                maskkktensor_id = daichuli.topk(1).indices
                daichuli = torch.nn.functional.pad(daichuli, (0, 25 - len(_sents_pos[i])), value=0)
                maskkktensor = torch.zeros(daichuli.shape, dtype=torch.bool).cuda()
                maskkktensor = maskkktensor.scatter(1, maskkktensor_id, 1)
                atts.append(daichuli)

            rs = contract("ld,rl->rd", sequence_output[i], ht_att)

            rs_xi = my_entity_atts
            rongheH = torch.cat((hs_xi, hs), dim=-1)
            rongheT = torch.cat((ts_xi, ts), dim=-1)
            rongheR = torch.cat((rs_xi, rs), dim=-1)

            rongheH = self.relu(self.p1 + self.l1(rongheH))
            rongheT = self.relu(self.p2 + self.l2(rongheT))
            rongheR = self.relu(self.p3 + self.l3(rongheR))

            hss.append(rongheH)
            tss.append(rongheT)
            rss.append(rongheR)
            if _sents_pos:
                mask.append(maskkktensor)

        if _sents_pos:
            mask = torch.cat(mask, dim=0)
            atts = torch.cat(atts, dim=0)
        hss = torch.cat(hss, dim=0)
        tss = torch.cat(tss, dim=0)
        rss = torch.cat(rss, dim=0)

        return hss, rss, tss, atts, mask

    def forward(self,
                input_ids=None,
                attention_mask=None,
                labels=None,
                entity_pos=None,
                hts=None,
                sen_labels=None,
                sen_pos=None,
                return_senatt=False,
                return_score=False,
                ):

        sequence_output, attention = self.encode(input_ids, attention_mask)

        max_sen_num = self.max_sen_num
        if torch.isnan(sequence_output).any():
            print('bert nan')
            embed()

        hs, rs, ts ,atts,mask = self.new_get_hrt(sequence_output, attention, entity_pos, hts, sen_pos)

        atttt = atts
        hs = torch.tanh(self.head_extractor(torch.cat([hs, rs], dim=1)))
        ts = torch.tanh(self.tail_extractor(torch.cat([ts, rs], dim=1)))
        b1 = hs.view(-1, self.emb_size // self.block_size, self.block_size)
        b2 = ts.view(-1, self.emb_size // self.block_size, self.block_size)
        bl = (b1.unsqueeze(3) * b2.unsqueeze(2)).view(-1, self.emb_size * self.block_size)
        logits = self.bilinear(bl)

        output = (self.loss_fnt.get_label(logits, num_labels=self.num_labels),)

        if return_score:
            scores_topk = self.loss_fnt.get_score(logits, self.num_labels)
            output = output + (scores_topk[0], scores_topk[1], )

        if labels is not None:
            labels = [torch.tensor(label) for label in labels]

            if sen_labels is not None:
                num_idx_used = [ len(torch.nonzero(label[:,1:].sum(dim=-1))) for label in labels]
            labels = torch.cat(labels, dim=0).to(logits)

            loss = self.loss_fnt(logits.float(), labels.float())

            if sen_labels is not None: 
                s_labels = [torch.tensor(s_label) for s_label in sen_labels] 
                s_labels = torch.cat(s_labels, dim=0).to(0) 
                idx_used = torch.nonzero(labels[:,1:].sum(dim=-1)).view(-1)

                
                
                
                
                
                #
                
                #
                
                
                
                
                
                
                

                s_logits = atttt[idx_used]
                evi_loss = self.evloss(s_logits.float(), s_labels.float())
                
                loss = loss + 0.001*evi_loss
                

                if torch.isnan(loss):
                    print('loss nan')
                    embed()

                if return_senatt:
                    s_output = s_logits.view(-1, self.max_sen_num, self.num_rels)
                    output = output + (s_output, )

            output = (loss.to(sequence_output),) + output

        elif return_senatt:



            s_logits = atttt
            s_output = s_logits > 0
            output = output + (s_output, )

        return output
