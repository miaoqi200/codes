
 
## 1. Environments

- python (3.6.8)
- cuda (10.1)

## 2. Dependencies

- numpy (1.17.3)
- torch (1.6.0)
- transformers (3.5.1)
- pandas (1.1.5)
- scikit-learn (0.23.2)

## 3. Preparation

- Download [DocRED](https://github.com/thunlp/DocRED) dataset
- Put all the `train_annotated.json`, `dev.json`, `test.json`, `train_distant.json` into all folders called `docred/`

## 4. Run
(1) First do the first reasoning:
```bash
>> python relation_extraction_model/trian_better_2.py
```
The parameters of our first reasoning module can be downloaded from [here](https://drive.google.com/file/d/16YoTkQtk9cGqBUdNQgoqZ14Qm334tzad/view?usp=sharing).

(2)Rename the parameters of the first reasoning module to "EIDER_xlnet9_eider_test_best.pt" and put it in the folder "dummy_document/", and put in the model of the first reasoning module to create dummy documents:
```bash
>> python dummy_document/train_evi.py
```
(3)Put the development and test results of the pseudo-document into the "secondary_reasoning_model/" folder, and import the parameters of the first reasoning, and then perform the second reasoning:
```bash
>> python secondary_reasoning_model/forth/train.py
```
The parameters of our second reasoning module can be downloaded from [here](https://drive.google.com/file/d/1Hpfa23FoyDJSsQABg19eINwZq7k6aZcw/view?usp=sharing).
## 5. Submission to LeadBoard (CodaLab)

Add the results of (2) and (3) together to  `result.json`. Then you can submit it to [CodaLab](https://competitions.codalab.org/competitions/20717#learn_the_details).

Additionally, the hard dataset sampled for this paper can be downloaded from [here](https://drive.google.com/file/d/13pKMdJELYpWbE5QpPUo2eROKxUFityLD/view?usp=sharing).