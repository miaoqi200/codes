import argparse
import os
import os
 
import json

#



os.environ['CUDA_VISIBLE_DEVICES'] = '1'
import numpy as np
import torch

import ujson as json
from torch.utils.data import DataLoader
from transformers import AutoConfig, AutoModel, AutoTokenizer
from transformers.optimization import AdamW, get_linear_schedule_with_warmup
from model import DocREModel
from utils import set_seed, collate_fn
from prepro import read_docred
from evaluation import to_official, official_evaluate


def trainmodel(args, model, train_features, dev_features,name, test_features):


    def finetune(train_features,dev_features,test_features, optimizer, num_epoch, num_steps):
        Loss = torch.nn.BCEWithLogitsLoss()

        best_score = 0
        best_test_f1=-1
        train_dataloader = DataLoader(train_features, batch_size=args.train_batch_size, shuffle=True, collate_fn=collate_fn, drop_last=True)
        train_iterator = range(int(num_epoch))
        total_steps = int(len(train_dataloader) * num_epoch // args.gradient_accumulation_steps)
        warmup_steps = int(total_steps * args.warmup_ratio)
        scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=warmup_steps, num_training_steps=total_steps)
        print("Total steps: {}".format(total_steps))
        print("Warmup steps: {}".format(warmup_steps))
        for epoch in train_iterator:
            model.zero_grad()
            cou=0
            for step, batch in enumerate(train_dataloader):
                model.train()
                cou+=1
                
                
                
                inputs = {'input_ids': batch[0].to(args.device),
                          'attention_mask': batch[1].to(args.device),
                          'labels': batch[2],
                          'entity_pos': batch[3],
                          'hts': batch[4],
                          'index':batch[5],
                          'title':batch[6]
                          }

                outputs = model(**inputs)
                
                lables = torch.tensor([uu for u in batch[2] for uu in u]).cuda()
                
                
                loss = Loss(outputs,lables.to(torch.float))

                

                

                
                loss.backward()

                if step % args.gradient_accumulation_steps == 0:
                    
                    
                    optimizer.step()
                    scheduler.step()
                    model.zero_grad()
                    num_steps += 1

                if  step%1==0:
                    dataloader = DataLoader(dev_features, batch_size=1, shuffle=False, collate_fn=collate_fn,
                                        drop_last=False)
                    dataloader_test = DataLoader(test_features, batch_size=1, shuffle=False, collate_fn=collate_fn,
                                            drop_last=False)

                    preds = []
                    zhengque=0
                    cuowu=0
                    bengyinggaidui = 0
                    ansss = []

                    test_ansss=[]

                    test_zhengque,test_cuowu=0,0
                    for batch11 in dataloader_test:
                        model.eval()

                        inputs2 = {'input_ids': batch11[0].to(args.device),
                                  'attention_mask': batch11[1].to(args.device),
                                  'entity_pos': batch11[3],
                                  'hts': batch11[4],
                                  'index': batch11[5],
                                  'title': batch11[6]
                                  }

                        with torch.no_grad():
                            pred1 = model(**inputs2)
                            pred1 = pred1.cpu()
                            pred1= pred1.argmax(dim=1)
                            
                            
                            
                            for rrrr1 in range(pred1.shape[0]):

                                if pred1[rrrr1]==1:
                                    ryryr1 = {'title': batch11[6][0], 'h_idx': int(batch11[4][0][rrrr1][0]), 't_idx':  int(batch11[4][0][rrrr1][1]), 'r': name.split('/')[-1]}
                                    if ryryr1 not in test_ansss:
                                        test_ansss.append(ryryr1)


                    
                    
                    

                    for batch1 in dataloader:
                        model.eval()

                        inputs = {'input_ids': batch1[0].to(args.device),
                                  'attention_mask': batch1[1].to(args.device),
                                  'entity_pos': batch1[3],
                                  'hts': batch1[4],
                                  'index': batch1[5],
                                  'title': batch1[6]
                                  }

                        with torch.no_grad():
                            pred = model(**inputs)
                            pred = pred.cpu()
                            pred= pred.argmax(dim=1)
                            
                            lables2 = torch.tensor([uu for u in batch1[2] for uu in u])
                            lables2 = lables2.argmax(dim=1)
                            for rrrr in range(pred.shape[0]):

                                if pred[rrrr]==lables2[rrrr] and pred[rrrr]:
                                    zhengque+=1
                                    
                                if lables2[rrrr]==0 and pred[rrrr]==1:
                                    cuowu+=1
                                if lables2[rrrr]==1 and pred[rrrr]==0:
                                    bengyinggaidui+=1
                                if pred[rrrr]==1:
                                    ryryr = {'title': batch1[6][0], 'h_idx': int(batch1[4][0][rrrr][0]), 't_idx':  int(batch1[4][0][rrrr][1]), 'r': name.split('/')[-1]}
                                    if ryryr not in ansss:
                                        ansss.append(ryryr)


                    acc = zhengque/(zhengque+cuowu+1e-10)
                    recall = zhengque/(zhengque+bengyinggaidui+1e-10)
                    f_now = 2*acc*recall/(acc+recall+1e-10)
                    if f_now>best_score:
                    
                    
                        best_score=f_now
                        json.dump(ansss,open(name+"_add_dev_"+str(f_now)[0:5]+"_.json","w",encoding="utf8"))
                        json.dump(test_ansss, open(name+"_add_test_"+str(f_now)[0:5] + "_.json", "w", encoding="utf8"))
                        print(int(f_now*10000)/10000,zhengque,cuowu,"best",best_score)
                        torch.save(model.state_dict(), name+".phttt")


        return num_steps

    new_layer = ["extractor", "bilinear"]
    optimizer_grouped_parameters = [
        {"params": [p for n, p in model.named_parameters() if not any(nd in n for nd in new_layer)], },
        {"params": [p for n, p in model.named_parameters() if any(nd in n for nd in new_layer)], "lr": 1e-4},
    ]

    optimizer = AdamW(optimizer_grouped_parameters, lr=args.learning_rate, eps=args.adam_epsilon)
    
    num_steps = 0
    set_seed(args)
    model.zero_grad()
    finetune(train_features,dev_features,test_features, optimizer, args.num_train_epochs, num_steps)


def handle(train,res_all_train,dumpname,ralation_num):
    train_trp = []
    train_trp_index_all={}
    train_name = []
    N=0
    for relation, v in res_all_train.items():
        N+=1
        if N!=ralation_num:
            continue
        for k,vv in v.items():

            train_name.append(k)
            train_trp_index={}
            for tiao in vv:
                for i in tiao['sheng']:
                    for ii in tiao['tuili']:
                        beiduan = list(set(tiao['sheng']+tiao['you'])-set([i]))
                        if len(beiduan)>=1:
                            train_trp.append((k,relation,int(i),int(ii)))
                            train_trp_index[str(float(i))+" "+str(float(ii))]=[[tiao['lianxutxt'][0],tiao['lianxutxt'][-1]],tiao['you'][0] if tiao['you'] else -1,beiduan[0],beiduan[-1]]    


                        else:
                            train_trp.append((k, relation, int(i),int(ii) ))
                            train_trp_index[str(float(i))+" "+str(float(ii))] = [[tiao['lianxutxt'][0], tiao['lianxutxt'][-1]],tiao['you'][0] if tiao['you'] else -1 ,i,
                                                      i]  

                            
                            
            train_trp_index_all[k] = train_trp_index
    newtrain = []
    for sample_i in range(len(train)):
        sample = train[sample_i]
        g = {}
        if sample['title'] in train_name:
            g['index'] = train_trp_index_all[sample['title']]
            labels = []
            try:
                for i in sample['labels']:
                    if (sample['title'],i['r'],i['h'],i['t']) in train_trp:
                        
                        for kkk,vvv in train_trp_index_all[sample['title']].items():
                            a1,b1 = kkk.split(" ")
                            a1,b1 = float(a1),float(b1)
                            if int(a1)==i['h'] and int(b1)==i['t'] and a1:
                                labels.append({'r': i['r'], 'h': a1, 't': b1, 'evidence': i['evidence']})
                                
            except:
                pass
            g['labels'] = labels
            g['title']=sample['title']
            g['vertexSet'] = sample['vertexSet']
            g['sents'] = sample['sents']
            newtrain.append(g)
    json.dump(newtrain,open(dumpname+".json",'w',encoding="utf8"))



def report(args, model, features):

    dataloader = DataLoader(features, batch_size=args.test_batch_size, shuffle=False, collate_fn=collate_fn, drop_last=False)
    preds = []
    for batch in dataloader:
        model.eval()

        inputs = {'input_ids': batch[0].to(args.device),
                  'attention_mask': batch[1].to(args.device),
                  'entity_pos': batch[3],
                  'hts': batch[4],
                  'index': batch[5],
                  'title': batch[6]
                  }

        with torch.no_grad():
            pred, *_ = model(**inputs)
            pred = pred.cpu().numpy()
            pred[np.isnan(pred)] = 0
            preds.append(pred)

    preds = np.concatenate(preds, axis=0).astype(np.float32)
    preds = to_official(preds, features)
    return preds


def main(name):
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", default="./dataset/docred", type=str)
    parser.add_argument("--transformer_type", default="xlnet", type=str)
    
    parser.add_argument("--model_name_or_path", default="xlnet-base-cased", type=str)
    

    parser.add_argument("--train_file", default="train_annotated_g.json", type=str)
    parser.add_argument("--dev_file", default="dev_g.json", type=str)
    parser.add_argument("--test_file", default="test_g.json", type=str)
    parser.add_argument("--save_path", default="", type=str)
    parser.add_argument("--load_path", default="", type=str)

    parser.add_argument("--config_name", default="", type=str,
                        help="Pretrained config name or path if not the same as model_name")
    parser.add_argument("--tokenizer_name", default="", type=str,
                        help="Pretrained tokenizer name or path if not the same as model_name")
    parser.add_argument("--max_seq_length", default=1024, type=int,
                        help="The maximum total input sequence length after tokenization. Sequences longer "
                             "than this will be truncated, sequences shorter will be padded.")

    
    
    parser.add_argument("--train_batch_size", default=4, type=int,
                        help="Batch size for training.")
    parser.add_argument("--test_batch_size", default=4, type=int,
                        help="Batch size for testing.")
    parser.add_argument("--gradient_accumulation_steps", default=1, type=int,
                        help="Number of updates steps to accumulate before performing a backward/update pass.")
    parser.add_argument("--num_labels", default=3, type=int,
                        help="Max number of labels in prediction.")
    parser.add_argument("--learning_rate", default=0.0002, type=float,
                        help="The initial learning rate for Adam.")
    parser.add_argument("--adam_epsilon", default=1e-6, type=float,
                        help="Epsilon for Adam optimizer.")
    parser.add_argument("--max_grad_norm", default=1.0, type=float,
                        help="Max gradient norm.")
    parser.add_argument("--warmup_ratio", default=0.06, type=float,
                        help="Warm up ratio for Adam.")
    parser.add_argument("--num_train_epochs", default=200, type=float,
                        help="Total number of training epochs to perform.")
    parser.add_argument("--evaluation_steps", default=50, type=int,
                        help="Number of training steps between evaluations.")
    parser.add_argument("--seed", type=int, default=665,
                        help="random seed for initialization")
    parser.add_argument("--num_class", type=int, default=97,
                        help="Number of relation types in dataset.")

    args = parser.parse_args()
    

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    args.n_gpu = torch.cuda.device_count()
    args.device = device

    config = AutoConfig.from_pretrained(
        args.config_name if args.config_name else args.model_name_or_path,
        num_labels=args.num_class,
    )
    tokenizer = AutoTokenizer.from_pretrained(
        args.tokenizer_name if args.tokenizer_name else args.model_name_or_path,
    )

    read = read_docred

    train_file = os.path.join(args.data_dir, args.train_file)
    dev_file = os.path.join(args.data_dir, args.dev_file)
    test_file = os.path.join(args.data_dir, args.test_file)

    dev_features = read(dev_file, tokenizer, max_seq_length=args.max_seq_length)
    train_features = read(train_file, tokenizer, max_seq_length=args.max_seq_length)
    test_features = read(test_file, tokenizer, max_seq_length=args.max_seq_length)

    model = AutoModel.from_pretrained(
        args.model_name_or_path,
        from_tf=bool(".ckpt" in args.model_name_or_path),
        config=config,
    )

    config.cls_token_id = tokenizer.cls_token_id
    config.sep_token_id = tokenizer.sep_token_id
    config.transformer_type = args.transformer_type

    set_seed(args)
    model = DocREModel(config, model, num_labels=args.num_labels)
    model.to(0)
 

    if args.load_path == "":  
        model.load_state_dict(torch.load("xlnet_9.ph"),strict=False)
        trainmodel(args, model, train_features, dev_features,name, test_features=test_features)
    
    
    
    
    
        
        
        

def preeeeeee(path,dev_path,test_path):
    import json
    dev_path = path + dev_path
    test_path = path + test_path
    
    
    dev = json.load(open("dataset/docred/dev.json", "r", encoding='utf8'))
    ans = json.load(open(dev_path, "r", encoding='utf8'))
    newshuju = []
    for sample in dev:
        s = {}
        s['title'] = sample['title']
        s['labels'] = sample['labels']
        s['vertexSet'] = sample['vertexSet']
        s['sents'] = sample['sents']
        yyy = []
        for i in ans:
            if i['title'] == sample['title']:
                yyy.append({"h_idx": i['h_idx'], "t_idx": i['t_idx'], "r": i['r']})
        s['pre'] = yyy
        newshuju.append(s)
    devpre_json = newshuju
    

    dev = json.load(open("dataset/docred/test.json", "r", encoding='utf8'))
    ans = json.load(open(test_path, "r", encoding='utf8'))
    
    newshuju = []
    for sample in dev:
        s = {}
        s['title'] = sample['title']
        
        s['vertexSet'] = sample['vertexSet']
        s['sents'] = sample['sents']
        yyy = []
        for i in ans:
            if i['title'] == sample['title']:
                yyy.append({"h_idx": i['h_idx'], "t_idx": i['t_idx'], "r": i['r']})
        s['pre'] = yyy
        newshuju.append(s)
    testpre_json = newshuju
    

    import json

    train_Lianxu_datas = json.load(open("../1.predataa/train_annotated_Lianxu.json"))
    test_Lianxu_datas = json.load(open("../1.predataa/test_Lianxu.json"))
    testpre_datas = testpre_json
    test_data = json.load(open("../1.predataa/test.json"))
    NEEDMIN_sample = 500
    res_all_test = {}
    res_all_train = {}

    RR_datas = json.load(open("../../3.tainAgain_get_result/ATLOP-main/3.result/pre_ans.json"))
    train = json.load(open('../../3.tainAgain_get_result/ATLOP-main/dataset/docred/train_annotated.json'))

    candi = json.load(open('../../3.tainAgain_get_result/ATLOP-main/3.result/result.json'))
    candimap = {}
    shiti = {
        "ORG": 1,
        "LOC": 2,
        "PER": 4,

    }

    for i in candi:
        candimap[i] = {}
    for sample in train:
        labels = sample['labels']
        for one in labels:
            if one['r'] in candimap:
                h = sample['vertexSet'][one['h']][0]['type']
                if h not in shiti:
                    continue
                if h in candimap[one['r']]:
                    candimap[one['r']][h] += 1
                else:
                    candimap[one['r']][h] = 1
    candida = {}
    for k, v in candimap.items():
        ke, value = "", 0
        for k1, v1 in v.items():
            if v1 > value:
                ke = k1
                value = v1
        if value > NEEDMIN_sample:
            candida[k] = [ke, [i for i in shiti if i != ke]]
    

    print("hello")

    

    for key, value in candida.items():
        test_part_datas_per = {}
        key_r = key
        value_k = value[0]
        value_zz = value[1]
        for sample_title, entitylist_set in test_Lianxu_datas.items():

            
            
            test_sample_info = [i for i in testpre_datas if i['title'] == sample_title][0]["vertexSet"]
            type_info = {}
            for i in range(len(test_sample_info)):
                type_info[i] = test_sample_info[i][0]['type']
            test_pre_sample = [i for i in testpre_datas if i['title'] == sample_title][0]['pre']
            RR_support = [i['ver_id'] for i in RR_datas if i['title'] == sample_title and i['r'] == key_r] + [i['t_idx']
                                                                                                              for
                                                                                                              i in
                                                                                                              test_pre_sample
                                                                                                              if i[
                                                                                                                  'r'] == key_r]
            testpre_support = [i['h_idx'] for i in test_pre_sample if i['r'] == key_r]
            entitylist_set, RR_support, testpre_support, type_info = entitylist_set, set(RR_support), set(
                testpre_support), type_info  
            for noun_string in entitylist_set:
                
                noun_string_types = [type_info[int(i)] for i in noun_string if
                                     type_info[int(i)] not in ["BLANK", "TIME", "NUM", "MISC"]]

                if value_k not in noun_string_types:
                    continue

                if len(noun_string_types) < 3:
                    continue

                
                noun_string_RR = set([i for i in noun_string if int(i) in RR_support])
                if len(noun_string_RR) > 0:
                    continue

                
                
                

                pergeshu = [type_info[int(i)] for i in noun_string]
                peryou = [i for i in noun_string if int(i) in testpre_support]
                if pergeshu.count(value_k) > 5:
                    flaggg = 1
                    for ffffff in value_zz:
                        if ffffff in pergeshu:
                            flaggg = 0
                    if flaggg:
                        
                        if noun_string[0] in peryou or len(peryou) * 2 > pergeshu.count(value_k):
                            per_sheng = [i for i in noun_string if
                                         type_info[int(i)] == value_k and int(i) not in testpre_support and int(
                                             i) not in RR_support]  
                            if len(per_sheng) == 0 and len(peryou) == 0:
                                continue
                            per_you = [i for i in noun_string if
                                       type_info[int(i)] == value_k and int(i) in testpre_support]  

                            one_data = {}
                            one_data['rr'] = list(noun_string_RR)
                            one_data['lianxutxt'] = noun_string
                            one_data['you'] = per_you
                            one_data['sheng'] = per_sheng
                            
                            _ = [[ii['t_idx'] for ii in test_pre_sample if ii['r'] == key_r and ii['h_idx'] == int(i)]
                                 for i
                                 in per_you]
                            one_data['tuili'] = list(set([ii for i in _ for ii in i]))
                            
                            if sample_title in test_part_datas_per:
                                test_part_datas_per[sample_title].append(one_data)
                            else:
                                test_part_datas_per[sample_title] = [one_data]

                            
                            
                    continue

                
                
                
                

                per_sheng = [i for i in noun_string if
                             type_info[int(i)] == value_k and int(i) not in testpre_support and int(
                                 i) not in RR_support]
                flaggg = 1
                for ffffff in value_zz:
                    if ffffff in pergeshu:
                        flaggg = 0
                if len(per_sheng) <= 3 and flaggg:

                    
                    
                    per_you = [i for i in noun_string if
                               type_info[int(i)] == value_k and int(i) in testpre_support]  
                    if (len(per_you) > 1 or (len(per_you) == 1 and per_you[0] == noun_string[0])) and per_sheng:
                        

                        one_data = {}
                        one_data['rr'] = list(noun_string_RR)
                        one_data['lianxutxt'] = noun_string
                        one_data['you'] = per_you
                        one_data['sheng'] = per_sheng
                        
                        _ = [[ii['t_idx'] for ii in test_pre_sample if ii['r'] == key_r and ii['h_idx'] == int(i)] for i
                             in
                             per_you]
                        one_data['tuili'] = list(set([ii for i in _ for ii in i]))
                        
                        if sample_title in test_part_datas_per:
                            test_part_datas_per[sample_title].append(one_data)
                        else:
                            test_part_datas_per[sample_title] = [one_data]
                    continue
                    

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                

            
            
            
            for noun_string in entitylist_set:

                pergeshu = [type_info[int(i)] for i in noun_string]
                peryou = [i for i in noun_string if int(i) in testpre_support]
                noun_string_RR = set([i for i in noun_string if int(i) in RR_support])

                
                noun_string_types = [type_info[int(i)] for i in noun_string if
                                     type_info[int(i)] not in ["BLANK", "TIME", "NUM", "MISC"]]

                if value_k not in noun_string_types:
                    continue
                per_sheng = [i for i in noun_string if
                             type_info[int(i)] == value_k and int(i) not in testpre_support and int(
                                 i) not in RR_support]  
                per_you = [i for i in noun_string if type_info[int(i)] == value_k and int(i) in testpre_support]  

                if len(noun_string) < 3:
                    continue
                
                

                if len(per_sheng) <= 2 and noun_string_RR and len(per_sheng) > 0:
                    if len(set([type_info[int(i)] for i in noun_string if i not in noun_string_RR])) != 1 or len(
                            [type_info[int(i)] for i in noun_string if i not in noun_string_RR]) < 2:
                        continue
                    if len(noun_string_RR) == 1:
                        one_data = {}
                        one_data['rr'] = list(noun_string_RR)
                        one_data['lianxutxt'] = noun_string
                        one_data['you'] = per_you
                        one_data['sheng'] = per_sheng
                        
                        _ = [[ii['t_idx'] for ii in test_pre_sample if ii['r'] == key_r and ii['h_idx'] == int(i)] for i
                             in
                             per_you]
                        one_data['tuili'] = list(noun_string_RR)
                        
                        if sample_title in test_part_datas_per:
                            test_part_datas_per[sample_title].append(one_data)
                        else:
                            test_part_datas_per[sample_title] = [one_data]
                        
                        continue

                    if len(noun_string_RR) == 2 and per_you and per_sheng:
                        one_data = {}
                        one_data['rr'] = list(noun_string_RR)
                        one_data['lianxutxt'] = noun_string
                        one_data['you'] = per_you
                        one_data['sheng'] = per_sheng
                        
                        _ = [[ii['t_idx'] for ii in test_pre_sample if ii['r'] == key_r and ii['h_idx'] == int(i)] for i
                             in
                             per_you]
                        one_data['tuili'] = list(set([ii for i in _ for ii in i]))
                        
                        if sample_title in test_part_datas_per:
                            test_part_datas_per[sample_title].append(one_data)
                        else:
                            test_part_datas_per[sample_title] = [one_data]
                        
                        continue
                
                
                
                
                

                if len(per_sheng) >= 6 and noun_string_RR and len(per_sheng) > 0:
                    persehng_txt = [
                        set((test_sample_info[int(k1)][int(k1 * 100 % 100) - 1]['name'].replace("-", " ")).split(" "))
                        for k1
                        in
                        per_sheng]
                    f = 0
                    for qq1 in range(len(persehng_txt)):
                        for qq2 in range(qq1 + 1, len(persehng_txt)):
                            if persehng_txt[qq1] & persehng_txt[qq2]:
                                
                                f = 1
                                break

                    if (int(noun_string[0]) in RR_support and f) or (int(noun_string[-1]) in RR_support and per_you):
                        
                        
                        one_data = {}
                        one_data['rr'] = list(noun_string_RR)
                        one_data['lianxutxt'] = noun_string
                        one_data['you'] = per_you
                        one_data['sheng'] = per_sheng
                        
                        _ = [[ii['t_idx'] for ii in test_pre_sample if ii['r'] == key_r and ii['h_idx'] == int(i)] for i
                             in
                             per_you]
                        dai = list(set([ii for i in _ for ii in i]))
                        if dai:
                            one_data['tuili'] = dai
                        elif int(noun_string[0]) in RR_support:
                            one_data['tuili'] = [int(noun_string[0])]
                        elif int(noun_string[-1]) in RR_support:
                            one_data['tuili'] = [int(noun_string[-1])]
                        else:
                            continue

                        
                        if sample_title in test_part_datas_per:
                            test_part_datas_per[sample_title].append(one_data)
                        else:
                            test_part_datas_per[sample_title] = [one_data]
                        
                        continue

        res_all_test[key_r] = test_part_datas_per
        
        n, m = 0, 0
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        
        
        
    for key, value in candida.items():
        test_part_datas_per = {}
        key_r = key
        value_k = value[0]
        value_zz = value[1]
        for sample_title, entitylist_set in train_Lianxu_datas.items():

            test_sample_info = [i for i in train if i['title'] == sample_title][0]["vertexSet"]
            type_info = {}
            for i in range(len(test_sample_info)):
                type_info[i] = test_sample_info[i][0]['type']
            test_pre_sample = [i for i in train if i['title'] == sample_title][0]['labels']
            RR_support = [i['ver_id'] for i in RR_datas if i['title'] == sample_title and i['r'] == key_r] + [i['t'] for
                                                                                                              i in
                                                                                                              test_pre_sample
                                                                                                              if i[
                                                                                                                  'r'] == key_r]
            testpre_support = [i['h'] for i in test_pre_sample if i['r'] == key_r]
            entitylist_set, RR_support, testpre_support, type_info = entitylist_set, set(RR_support), set(
                testpre_support), type_info  
            for noun_string in entitylist_set:
                
                noun_string_types = [type_info[int(i)] for i in noun_string if
                                     type_info[int(i)] not in ["BLANK", "TIME", "NUM", "MISC"]]

                if value_k not in noun_string_types:
                    continue

                if len(noun_string_types) < 3:
                    continue

                
                noun_string_RR = set([i for i in noun_string if int(i) in RR_support])
                if len(noun_string_RR) > 0:
                    continue

                
                
                

                pergeshu = [type_info[int(i)] for i in noun_string]
                peryou = [i for i in noun_string if int(i) in testpre_support]
                if pergeshu.count(value_k) > 5:
                    flaggg = 1
                    for ffffff in value_zz:
                        if ffffff in pergeshu:
                            flaggg = 0
                    if flaggg:
                        
                        if noun_string[0] in peryou or len(peryou) * 2 > pergeshu.count(value_k):
                            per_sheng = [i for i in noun_string if
                                         type_info[int(i)] == value_k and int(i) not in testpre_support and int(
                                             i) not in RR_support]  
                            if len(peryou) == 0:
                                continue
                            per_you = [i for i in noun_string if
                                       type_info[int(i)] == value_k and int(i) in testpre_support]  

                            one_data = {}
                            one_data['rr'] = list(noun_string_RR)
                            one_data['lianxutxt'] = noun_string
                            one_data['you'] = per_you
                            one_data['sheng'] = per_sheng + per_you
                            
                            _ = [[ii['t'] for ii in test_pre_sample if ii['r'] == key_r and ii['h'] == int(i)] for i
                                 in per_you]
                            one_data['tuili'] = list(set([ii for i in _ for ii in i]))
                            
                            if sample_title in test_part_datas_per:
                                test_part_datas_per[sample_title].append(one_data)
                            else:
                                test_part_datas_per[sample_title] = [one_data]

                            
                            
                    continue

                
                
                
                

                per_sheng = [i for i in noun_string if
                             type_info[int(i)] == value_k and int(i) not in testpre_support and int(
                                 i) not in RR_support]
                flaggg = 1
                for ffffff in value_zz:
                    if ffffff in pergeshu:
                        flaggg = 0
                if len(per_sheng) <= 3 and flaggg:

                    
                    
                    per_you = [i for i in noun_string if
                               type_info[int(i)] == value_k and int(i) in testpre_support]  
                    if (len(per_you) > 1 or (len(per_you) == 1 and per_you[0] == noun_string[0])):
                        

                        one_data = {}
                        one_data['rr'] = list(noun_string_RR)
                        one_data['lianxutxt'] = noun_string
                        one_data['you'] = per_you
                        one_data['sheng'] = per_sheng + per_you
                        
                        _ = [[ii['t'] for ii in test_pre_sample if ii['r'] == key_r and ii['h'] == int(i)] for i in
                             per_you]
                        one_data['tuili'] = list(set([ii for i in _ for ii in i]))
                        
                        if sample_title in test_part_datas_per:
                            test_part_datas_per[sample_title].append(one_data)
                        else:
                            test_part_datas_per[sample_title] = [one_data]
                    continue
                    

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                

            
            
            
            for noun_string in entitylist_set:

                pergeshu = [type_info[int(i)] for i in noun_string]
                peryou = [i for i in noun_string if int(i) in testpre_support]
                noun_string_RR = set([i for i in noun_string if int(i) in RR_support])

                
                noun_string_types = [type_info[int(i)] for i in noun_string if
                                     type_info[int(i)] not in ["BLANK", "TIME", "NUM", "MISC"]]

                if value_k not in noun_string_types:
                    continue
                per_sheng = [i for i in noun_string if
                             type_info[int(i)] == value_k and int(i) not in testpre_support and int(
                                 i) not in RR_support]  
                per_you = [i for i in noun_string if type_info[int(i)] == value_k and int(i) in testpre_support]  

                if len(noun_string) < 3:
                    continue
                
                

                if len(per_sheng) <= 2 and noun_string_RR:
                    if len(set([type_info[int(i)] for i in noun_string if i not in noun_string_RR])) != 1 or len(
                            [type_info[int(i)] for i in noun_string if i not in noun_string_RR]) < 2:
                        continue
                    if len(noun_string_RR) == 1:
                        one_data = {}
                        one_data['rr'] = list(noun_string_RR)
                        one_data['lianxutxt'] = noun_string
                        one_data['you'] = per_you
                        one_data['sheng'] = per_sheng + per_you
                        
                        _ = [[ii['t'] for ii in test_pre_sample if ii['r'] == key_r and ii['h'] == int(i)] for i in
                             per_you]
                        one_data['tuili'] = list(noun_string_RR)
                        
                        if sample_title in test_part_datas_per:
                            test_part_datas_per[sample_title].append(one_data)
                        else:
                            test_part_datas_per[sample_title] = [one_data]
                        
                        continue

                    if len(noun_string_RR) == 2 and per_you:
                        one_data = {}
                        one_data['rr'] = list(noun_string_RR)
                        one_data['lianxutxt'] = noun_string
                        one_data['you'] = per_you
                        one_data['sheng'] = per_sheng + per_you
                        
                        _ = [[ii['t'] for ii in test_pre_sample if ii['r'] == key_r and ii['h'] == int(i)] for i in
                             per_you]
                        one_data['tuili'] = list(set([ii for i in _ for ii in i]))
                        
                        if sample_title in test_part_datas_per:
                            test_part_datas_per[sample_title].append(one_data)
                        else:
                            test_part_datas_per[sample_title] = [one_data]
                        
                        continue
                
                
                
                
                

                if len(per_sheng + per_you) >= 6 and noun_string_RR:
                    persehng_txt = [
                        set((test_sample_info[int(k1)][int(k1 * 100 % 100) - 1]['name'].replace("-", " ")).split(" "))
                        for k1
                        in
                        per_sheng + per_you]
                    f = 0
                    for qq1 in range(len(persehng_txt)):
                        for qq2 in range(qq1 + 1, len(persehng_txt)):
                            if persehng_txt[qq1] & persehng_txt[qq2]:
                                
                                f = 1
                                break

                    if (int(noun_string[0]) in RR_support and f) or (int(noun_string[-1]) in RR_support and per_you):
                        
                        
                        one_data = {}
                        one_data['rr'] = list(noun_string_RR)
                        one_data['lianxutxt'] = noun_string
                        one_data['you'] = per_you
                        one_data['sheng'] = per_sheng + per_you
                        
                        _ = [[ii['t'] for ii in test_pre_sample if ii['r'] == key_r and ii['h'] == int(i)] for i in
                             per_you]
                        dai = list(set([ii for i in _ for ii in i]))
                        if dai:
                            one_data['tuili'] = dai
                        elif int(noun_string[0]) in RR_support:
                            one_data['tuili'] = [int(noun_string[0])]
                        elif int(noun_string[-1]) in RR_support:
                            one_data['tuili'] = [int(noun_string[-1])]
                        else:
                            continue

                        
                        if sample_title in test_part_datas_per:
                            test_part_datas_per[sample_title].append(one_data)
                        else:
                            test_part_datas_per[sample_title] = [one_data]
                        
                        continue

        res_all_train[key_r] = test_part_datas_per
        
        n, m = 0, 0
        for title, samplelines in test_part_datas_per.items():
            sample = [i for i in train if i['title'] == title][0]['labels']
            labels = [(i['h'], i['t']) for i in sample if i['r'] == key_r]
            for sampleline in samplelines:
                prelable = []
                for i in sampleline["sheng"]:
                    
                    
                    for ii in sampleline['tuili']:
                        prelable.append((int(i), int(sampleline['tuili'][0])))
                for i in prelable:
                    if i in labels:
                        n += 1
                    else:
                        m += 1
        print(n, m)

        
        
        

    
    
    
    #
    
    dev_Lianxu_datas = json.load(open("../1.predataa/dev_Lianxu.json"))
    devpre_datas = devpre_json
    dev_data = json.load(open("../1.predataa/dev.json"))
    NEEDMIN_sample = 500
    res_all_dev = {}
    res_all_train = {}

    
    
    #
    
    candimap = {}
    shiti = {
        "ORG": 1,
        "LOC": 2,
        "PER": 4,

    }

    for i in candi:
        candimap[i] = {}
    for sample in train:
        labels = sample['labels']
        for one in labels:
            if one['r'] in candimap:
                h = sample['vertexSet'][one['h']][0]['type']
                if h not in shiti:
                    continue
                if h in candimap[one['r']]:
                    candimap[one['r']][h] += 1
                else:
                    candimap[one['r']][h] = 1
    candida = {}
    for k, v in candimap.items():
        ke, value = "", 0
        for k1, v1 in v.items():
            if v1 > value:
                ke = k1
                value = v1
        if value > NEEDMIN_sample:
            candida[k] = [ke, [i for i in shiti if i != ke]]
    

    print("hello")

    

    for key, value in candida.items():
        dev_part_datas_per = {}
        key_r = key
        value_k = value[0]
        value_zz = value[1]
        for sample_title, entitylist_set in dev_Lianxu_datas.items():

            
            
            dev_sample_info = [i for i in devpre_datas if i['title'] == sample_title][0]["vertexSet"]
            type_info = {}
            for i in range(len(dev_sample_info)):
                type_info[i] = dev_sample_info[i][0]['type']
            dev_pre_sample = [i for i in devpre_datas if i['title'] == sample_title][0]['pre']
            RR_support = [i['ver_id'] for i in RR_datas if i['title'] == sample_title and i['r'] == key_r] + [i['t_idx']
                                                                                                              for
                                                                                                              i in
                                                                                                              dev_pre_sample
                                                                                                              if i[
                                                                                                                  'r'] == key_r]
            devpre_support = [i['h_idx'] for i in dev_pre_sample if i['r'] == key_r]
            entitylist_set, RR_support, devpre_support, type_info = entitylist_set, set(RR_support), set(
                devpre_support), type_info  
            for noun_string in entitylist_set:
                
                noun_string_types = [type_info[int(i)] for i in noun_string if
                                     type_info[int(i)] not in ["BLANK", "TIME", "NUM", "MISC"]]

                if value_k not in noun_string_types:
                    continue

                if len(noun_string_types) < 3:
                    continue

                
                noun_string_RR = set([i for i in noun_string if int(i) in RR_support])
                if len(noun_string_RR) > 0:
                    continue

                
                
                

                pergeshu = [type_info[int(i)] for i in noun_string]
                peryou = [i for i in noun_string if int(i) in devpre_support]
                if pergeshu.count(value_k) > 5:
                    flaggg = 1
                    for ffffff in value_zz:
                        if ffffff in pergeshu:
                            flaggg = 0
                    if flaggg:
                        
                        if noun_string[0] in peryou or len(peryou) * 2 > pergeshu.count(value_k):
                            per_sheng = [i for i in noun_string if
                                         type_info[int(i)] == value_k and int(i) not in devpre_support and int(
                                             i) not in RR_support]  
                            if len(per_sheng) == 0 and len(peryou) == 0:
                                continue
                            per_you = [i for i in noun_string if
                                       type_info[int(i)] == value_k and int(i) in devpre_support]  

                            one_data = {}
                            one_data['rr'] = list(noun_string_RR)
                            one_data['lianxutxt'] = noun_string
                            one_data['you'] = per_you
                            one_data['sheng'] = per_sheng
                            
                            _ = [[ii['t_idx'] for ii in dev_pre_sample if ii['r'] == key_r and ii['h_idx'] == int(i)]
                                 for i
                                 in per_you]
                            one_data['tuili'] = list(set([ii for i in _ for ii in i]))
                            
                            if sample_title in dev_part_datas_per:
                                dev_part_datas_per[sample_title].append(one_data)
                            else:
                                dev_part_datas_per[sample_title] = [one_data]

                            
                            
                    continue

                
                
                
                

                per_sheng = [i for i in noun_string if
                             type_info[int(i)] == value_k and int(i) not in devpre_support and int(i) not in RR_support]
                flaggg = 1
                for ffffff in value_zz:
                    if ffffff in pergeshu:
                        flaggg = 0
                if len(per_sheng) <= 3 and flaggg:

                    
                    
                    per_you = [i for i in noun_string if
                               type_info[int(i)] == value_k and int(i) in devpre_support]  
                    if (len(per_you) > 1 or (len(per_you) == 1 and per_you[0] == noun_string[0])) and per_sheng:
                        

                        one_data = {}
                        one_data['rr'] = list(noun_string_RR)
                        one_data['lianxutxt'] = noun_string
                        one_data['you'] = per_you
                        one_data['sheng'] = per_sheng
                        
                        _ = [[ii['t_idx'] for ii in dev_pre_sample if ii['r'] == key_r and ii['h_idx'] == int(i)] for i
                             in
                             per_you]
                        one_data['tuili'] = list(set([ii for i in _ for ii in i]))
                        
                        if sample_title in dev_part_datas_per:
                            dev_part_datas_per[sample_title].append(one_data)
                        else:
                            dev_part_datas_per[sample_title] = [one_data]
                    continue
                    

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                

            
            
            
            for noun_string in entitylist_set:

                pergeshu = [type_info[int(i)] for i in noun_string]
                peryou = [i for i in noun_string if int(i) in devpre_support]
                noun_string_RR = set([i for i in noun_string if int(i) in RR_support])

                
                noun_string_types = [type_info[int(i)] for i in noun_string if
                                     type_info[int(i)] not in ["BLANK", "TIME", "NUM", "MISC"]]

                if value_k not in noun_string_types:
                    continue
                per_sheng = [i for i in noun_string if
                             type_info[int(i)] == value_k and int(i) not in devpre_support and int(
                                 i) not in RR_support]  
                per_you = [i for i in noun_string if type_info[int(i)] == value_k and int(i) in devpre_support]  

                if len(noun_string) < 3:
                    continue
                
                

                if len(per_sheng) <= 2 and noun_string_RR and len(per_sheng) > 0:
                    if len(set([type_info[int(i)] for i in noun_string if i not in noun_string_RR])) != 1 or len(
                            [type_info[int(i)] for i in noun_string if i not in noun_string_RR]) < 2:
                        continue
                    if len(noun_string_RR) == 1:
                        one_data = {}
                        one_data['rr'] = list(noun_string_RR)
                        one_data['lianxutxt'] = noun_string
                        one_data['you'] = per_you
                        one_data['sheng'] = per_sheng
                        
                        _ = [[ii['t_idx'] for ii in dev_pre_sample if ii['r'] == key_r and ii['h_idx'] == int(i)] for i
                             in
                             per_you]
                        one_data['tuili'] = list(noun_string_RR)
                        
                        if sample_title in dev_part_datas_per:
                            dev_part_datas_per[sample_title].append(one_data)
                        else:
                            dev_part_datas_per[sample_title] = [one_data]
                        
                        continue

                    if len(noun_string_RR) == 2 and per_you and per_sheng:
                        one_data = {}
                        one_data['rr'] = list(noun_string_RR)
                        one_data['lianxutxt'] = noun_string
                        one_data['you'] = per_you
                        one_data['sheng'] = per_sheng
                        
                        _ = [[ii['t_idx'] for ii in dev_pre_sample if ii['r'] == key_r and ii['h_idx'] == int(i)] for i
                             in
                             per_you]
                        one_data['tuili'] = list(set([ii for i in _ for ii in i]))
                        
                        if sample_title in dev_part_datas_per:
                            dev_part_datas_per[sample_title].append(one_data)
                        else:
                            dev_part_datas_per[sample_title] = [one_data]
                        
                        continue
                
                
                
                
                

                if len(per_sheng) >= 6 and noun_string_RR and len(per_sheng) > 0:
                    persehng_txt = [
                        set((dev_sample_info[int(k1)][int(k1 * 100 % 100) - 1]['name'].replace("-", " ")).split(" "))
                        for k1
                        in
                        per_sheng]
                    f = 0
                    for qq1 in range(len(persehng_txt)):
                        for qq2 in range(qq1 + 1, len(persehng_txt)):
                            if persehng_txt[qq1] & persehng_txt[qq2]:
                                
                                f = 1
                                break

                    if (int(noun_string[0]) in RR_support and f) or (int(noun_string[-1]) in RR_support and per_you):
                        
                        
                        one_data = {}
                        one_data['rr'] = list(noun_string_RR)
                        one_data['lianxutxt'] = noun_string
                        one_data['you'] = per_you
                        one_data['sheng'] = per_sheng
                        
                        _ = [[ii['t_idx'] for ii in dev_pre_sample if ii['r'] == key_r and ii['h_idx'] == int(i)] for i
                             in
                             per_you]
                        dai = list(set([ii for i in _ for ii in i]))
                        if dai:
                            one_data['tuili'] = dai
                        elif int(noun_string[0]) in RR_support:
                            one_data['tuili'] = [int(noun_string[0])]
                        elif int(noun_string[-1]) in RR_support:
                            one_data['tuili'] = [int(noun_string[-1])]
                        else:
                            continue

                        
                        if sample_title in dev_part_datas_per:
                            dev_part_datas_per[sample_title].append(one_data)
                        else:
                            dev_part_datas_per[sample_title] = [one_data]
                        
                        continue

        res_all_dev[key_r] = dev_part_datas_per
        
        n, m = 0, 0
        for title, samplelines in dev_part_datas_per.items():
            sample = [i for i in dev_data if i['title'] == title][0]['labels']
            labels = [(i['h'], i['t']) for i in sample if i['r'] == key_r]
            for sampleline in samplelines:
                prelable = []
                for i in sampleline["sheng"]:
                    
                    
                    for ii in sampleline['tuili']:
                        prelable.append((int(i), int(sampleline['tuili'][0])))
                for i in prelable:
                    if i in labels:
                        n += 1
                    else:
                        m += 1
        print(n, m)

        
        
        
    for key, value in candida.items():
        dev_part_datas_per = {}
        key_r = key
        value_k = value[0]
        value_zz = value[1]
        for sample_title, entitylist_set in train_Lianxu_datas.items():

            dev_sample_info = [i for i in train if i['title'] == sample_title][0]["vertexSet"]
            type_info = {}
            for i in range(len(dev_sample_info)):
                type_info[i] = dev_sample_info[i][0]['type']
            dev_pre_sample = [i for i in train if i['title'] == sample_title][0]['labels']
            RR_support = [i['ver_id'] for i in RR_datas if i['title'] == sample_title and i['r'] == key_r] + [i['t'] for
                                                                                                              i in
                                                                                                              dev_pre_sample
                                                                                                              if i[
                                                                                                                  'r'] == key_r]
            devpre_support = [i['h'] for i in dev_pre_sample if i['r'] == key_r]
            entitylist_set, RR_support, devpre_support, type_info = entitylist_set, set(RR_support), set(
                devpre_support), type_info  
            for noun_string in entitylist_set:
                
                noun_string_types = [type_info[int(i)] for i in noun_string if
                                     type_info[int(i)] not in ["BLANK", "TIME", "NUM", "MISC"]]

                if value_k not in noun_string_types:
                    continue

                if len(noun_string_types) < 3:
                    continue

                
                noun_string_RR = set([i for i in noun_string if int(i) in RR_support])
                if len(noun_string_RR) > 0:
                    continue

                
                
                

                pergeshu = [type_info[int(i)] for i in noun_string]
                peryou = [i for i in noun_string if int(i) in devpre_support]
                if pergeshu.count(value_k) > 5:
                    flaggg = 1
                    for ffffff in value_zz:
                        if ffffff in pergeshu:
                            flaggg = 0
                    if flaggg:
                        
                        if noun_string[0] in peryou or len(peryou) * 2 > pergeshu.count(value_k):
                            per_sheng = [i for i in noun_string if
                                         type_info[int(i)] == value_k and int(i) not in devpre_support and int(
                                             i) not in RR_support]  
                            if len(peryou) == 0:
                                continue
                            per_you = [i for i in noun_string if
                                       type_info[int(i)] == value_k and int(i) in devpre_support]  

                            one_data = {}
                            one_data['rr'] = list(noun_string_RR)
                            one_data['lianxutxt'] = noun_string
                            one_data['you'] = per_you
                            one_data['sheng'] = per_sheng + per_you
                            
                            _ = [[ii['t'] for ii in dev_pre_sample if ii['r'] == key_r and ii['h'] == int(i)] for i
                                 in per_you]
                            one_data['tuili'] = list(set([ii for i in _ for ii in i]))
                            
                            if sample_title in dev_part_datas_per:
                                dev_part_datas_per[sample_title].append(one_data)
                            else:
                                dev_part_datas_per[sample_title] = [one_data]

                            
                            
                    continue

                
                
                
                

                per_sheng = [i for i in noun_string if
                             type_info[int(i)] == value_k and int(i) not in devpre_support and int(i) not in RR_support]
                flaggg = 1
                for ffffff in value_zz:
                    if ffffff in pergeshu:
                        flaggg = 0
                if len(per_sheng) <= 3 and flaggg:

                    
                    
                    per_you = [i for i in noun_string if
                               type_info[int(i)] == value_k and int(i) in devpre_support]  
                    if (len(per_you) > 1 or (len(per_you) == 1 and per_you[0] == noun_string[0])):
                        

                        one_data = {}
                        one_data['rr'] = list(noun_string_RR)
                        one_data['lianxutxt'] = noun_string
                        one_data['you'] = per_you
                        one_data['sheng'] = per_sheng + per_you
                        
                        _ = [[ii['t'] for ii in dev_pre_sample if ii['r'] == key_r and ii['h'] == int(i)] for i in
                             per_you]
                        one_data['tuili'] = list(set([ii for i in _ for ii in i]))
                        
                        if sample_title in dev_part_datas_per:
                            dev_part_datas_per[sample_title].append(one_data)
                        else:
                            dev_part_datas_per[sample_title] = [one_data]
                    continue
                    

                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                

            
            
            
            for noun_string in entitylist_set:

                pergeshu = [type_info[int(i)] for i in noun_string]
                peryou = [i for i in noun_string if int(i) in devpre_support]
                noun_string_RR = set([i for i in noun_string if int(i) in RR_support])

                
                noun_string_types = [type_info[int(i)] for i in noun_string if
                                     type_info[int(i)] not in ["BLANK", "TIME", "NUM", "MISC"]]

                if value_k not in noun_string_types:
                    continue
                per_sheng = [i for i in noun_string if
                             type_info[int(i)] == value_k and int(i) not in devpre_support and int(
                                 i) not in RR_support]  
                per_you = [i for i in noun_string if type_info[int(i)] == value_k and int(i) in devpre_support]  

                if len(noun_string) < 3:
                    continue
                
                

                if len(per_sheng) <= 2 and noun_string_RR:
                    if len(set([type_info[int(i)] for i in noun_string if i not in noun_string_RR])) != 1 or len(
                            [type_info[int(i)] for i in noun_string if i not in noun_string_RR]) < 2:
                        continue
                    if len(noun_string_RR) == 1:
                        one_data = {}
                        one_data['rr'] = list(noun_string_RR)
                        one_data['lianxutxt'] = noun_string
                        one_data['you'] = per_you
                        one_data['sheng'] = per_sheng + per_you
                        
                        _ = [[ii['t'] for ii in dev_pre_sample if ii['r'] == key_r and ii['h'] == int(i)] for i in
                             per_you]
                        one_data['tuili'] = list(noun_string_RR)
                        
                        if sample_title in dev_part_datas_per:
                            dev_part_datas_per[sample_title].append(one_data)
                        else:
                            dev_part_datas_per[sample_title] = [one_data]
                        
                        continue

                    if len(noun_string_RR) == 2 and per_you:
                        one_data = {}
                        one_data['rr'] = list(noun_string_RR)
                        one_data['lianxutxt'] = noun_string
                        one_data['you'] = per_you
                        one_data['sheng'] = per_sheng + per_you
                        
                        _ = [[ii['t'] for ii in dev_pre_sample if ii['r'] == key_r and ii['h'] == int(i)] for i in
                             per_you]
                        one_data['tuili'] = list(set([ii for i in _ for ii in i]))
                        
                        if sample_title in dev_part_datas_per:
                            dev_part_datas_per[sample_title].append(one_data)
                        else:
                            dev_part_datas_per[sample_title] = [one_data]
                        
                        continue
                
                
                
                
                

                if len(per_sheng + per_you) >= 6 and noun_string_RR:
                    persehng_txt = [
                        set((dev_sample_info[int(k1)][int(k1 * 100 % 100) - 1]['name'].replace("-", " ")).split(" "))
                        for k1
                        in
                        per_sheng + per_you]
                    f = 0
                    for qq1 in range(len(persehng_txt)):
                        for qq2 in range(qq1 + 1, len(persehng_txt)):
                            if persehng_txt[qq1] & persehng_txt[qq2]:
                                
                                f = 1
                                break

                    if (int(noun_string[0]) in RR_support and f) or (int(noun_string[-1]) in RR_support and per_you):
                        
                        
                        one_data = {}
                        one_data['rr'] = list(noun_string_RR)
                        one_data['lianxutxt'] = noun_string
                        one_data['you'] = per_you
                        one_data['sheng'] = per_sheng + per_you
                        
                        _ = [[ii['t'] for ii in dev_pre_sample if ii['r'] == key_r and ii['h'] == int(i)] for i in
                             per_you]
                        dai = list(set([ii for i in _ for ii in i]))
                        if dai:
                            one_data['tuili'] = dai
                        elif int(noun_string[0]) in RR_support:
                            one_data['tuili'] = [int(noun_string[0])]
                        elif int(noun_string[-1]) in RR_support:
                            one_data['tuili'] = [int(noun_string[-1])]
                        else:
                            continue

                        
                        if sample_title in dev_part_datas_per:
                            dev_part_datas_per[sample_title].append(one_data)
                        else:
                            dev_part_datas_per[sample_title] = [one_data]
                        
                        continue

        res_all_train[key_r] = dev_part_datas_per
        
        n, m = 0, 0
        for title, samplelines in dev_part_datas_per.items():
            sample = [i for i in train if i['title'] == title][0]['labels']
            labels = [(i['h'], i['t']) for i in sample if i['r'] == key_r]
            for sampleline in samplelines:
                prelable = []
                for i in sampleline["sheng"]:
                    
                    
                    for ii in sampleline['tuili']:
                        prelable.append((int(i), int(sampleline['tuili'][0])))
                for i in prelable:
                    if i in labels:
                        n += 1
                    else:
                        m += 1
        print(n, m)

        
        
        
    
    
    
    return res_all_train,res_all_dev,res_all_test


if __name__ == "__main__":
    path = "_devlog/mymodel_xlnet1234/"

    res_all_train, res_all_dev, res_all_test = preeeeeee(path=path,dev_path="dev_result_test_xlnet9_eider_test_best_xlnet-base-cased.json",
                                                         test_path="test_result_test_xlnet9_eider_test_best_xlnet-base-cased1.96875.json")




    
    
    all_relations = json.load(open("meta/relation.json", "r"))




    relation=0
    for name in all_relations:
        relation+=1
        

        train = json.load(open("dataset/docred/train_annotated.json"))
        dev = json.load(open("dataset/docred/dev.json"))
        test = json.load(open("dataset/docred/test.json"))

        handle(test, res_all_test, "dataset/docred/test_g", relation)
        handle(train, res_all_train, "dataset/docred/train_annotated_g", relation)
        handle(dev, res_all_dev, "dataset/docred/dev_g", relation)

        
        
        
        main(path+name)
