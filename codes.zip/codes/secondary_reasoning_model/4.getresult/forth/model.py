import torch
import torch.nn as nn
from opt_einsum import contract
from long_seq import process_long_input
from losses import ATLoss


class DocREModel(nn.Module):
    def __init__(self, config, model, emb_size=768, block_size=64, num_labels=-1):
        super().__init__()
        self.config = config
        self.model = model
        self.hidden_size = config.hidden_size
        self.loss_fnt = ATLoss()

        self.A_linear = nn.Linear(3 * 768, 100)
        self.end_linear = nn.Linear(3 * 100, 2)
        self.bilinear_rr = nn.Bilinear(in1_features=768,in2_features=768,out_features=100)
        self.liner2 =  nn.Linear(768, 100)

        
        self.emb_size = emb_size
        self.block_size = block_size
        self.num_labels = num_labels

        self.weight = nn.Parameter(torch.randn(1, 768))
        self.dp = nn.Dropout(0.5)

    def encode(self, input_ids, attention_mask):
        config = self.config
        if config.transformer_type == "bert":
            start_tokens = [config.cls_token_id]
            end_tokens = [config.sep_token_id]
        elif config.transformer_type == "roberta":
            start_tokens = [config.cls_token_id]
            end_tokens = [config.sep_token_id, config.sep_token_id]
        elif config.transformer_type == "xlnet":
            pass
        sequence_output, attention = process_long_input(self.model, input_ids, attention_mask, start_tokens=[], end_tokens=[])
        return sequence_output, attention

    def get_hrt(self, sequence_output, attention, entity_pos, hts,index):
        offset = 1 if self.config.transformer_type in ["bert", "roberta"] else 0
        n, h, _, c = attention.size()
        hss, sss,N1,N2= [], [],[],[]
        for i in range(len(entity_pos)): 
            mentions_token_pos = []
            all_entity_embs,entity_embs, entity_atts ,entity_myatts= [], [],[],[]
            for e in entity_pos[i]: 

                if len(e) > 1:
                    e_emb,e_emb_new, e_att,mye_att =[], [], [],[]
                    mentions_en_pos_bg = []

                    for start, end in e: 
                        if start + offset < c:  
                            
                            e_emb.append(sequence_output[i, start + offset])
                            e_emb_new.append(sequence_output[i, start + offset])  
                            mye_att.append(attention[i, :, start + offset].mean(0)) 
                            mentions_en_pos_bg.append(start + offset)
                            e_att.append(attention[i, :, start + offset])

                    if len(e_emb) > 0: 
                        e_emb = torch.logsumexp(torch.stack(e_emb, dim=0), dim=0)
                        
                        
                        e_emb_new =torch.stack(e_emb_new, dim=0)
                        e_att = torch.stack(e_att, dim=0).mean(0)
                    else:
                        e_emb = torch.zeros(self.config.hidden_size).to(sequence_output)
                        e_emb_new=torch.zeros(1,self.config.hidden_size).to(sequence_output)
                        mye_att.append(torch.zeros(h, c).mean(0).to(attention))
                        e_att = torch.zeros(h, c).to(attention)
                else:
                    e_emb,e_emb_new, e_att,mye_att = [],[], [],[]
                    mentions_en_pos_bg = []
                    start, end = e[0]
                    if start + offset < c:
                        e_emb = sequence_output[i, start + offset]
                        e_emb_new=sequence_output[i, start + offset].view(1,-1)
                        mentions_en_pos_bg.append(start + offset)
                        mye_att.append(attention[i, :, start + offset].mean(0))
                        e_att = attention[i, :, start + offset]
                    else:
                        e_emb = torch.zeros(self.config.hidden_size).to(sequence_output)
                        e_emb_new=torch.zeros(self.config.hidden_size).view(1,-1).to(sequence_output)
                        mentions_en_pos_bg.append(0)
                        mye_att.append(torch.zeros(h, c).mean(0).to(attention))
                        e_att = torch.zeros(h, c).to(attention)
                entity_embs.append(e_emb_new)
                entity_myatts.append(mye_att)
                mentions_token_pos.append(mentions_en_pos_bg)
                entity_atts.append(e_att)
                all_entity_embs.append(e_emb)


            
            hts_of_Sample_i = hts[i] 
            sample_i_mention_embings = entity_embs
            sample_i_mention_attention = entity_myatts
            


            
            
            
            
            
            
            


            
            RR_embs,You_embs,H_emb = [],[],[]  
            
            Duanyu,NR1,NR2 = [],[],[]
            for pair_pq in hts_of_Sample_i: 
                p_eid,q_eid = pair_pq  
                pq_index = index[i][str(float(p_eid))+" "+str(float(q_eid))]

                
                RR_id =[int(q_eid),int(q_eid*100%100+0.5)]
                if RR_id[1]==0:
                    RR =torch.logsumexp(sample_i_mention_embings[RR_id[0]], dim=0)
                    
                else:
                    RR_id[1]-=1
                    RR=sample_i_mention_embings[RR_id[0]][RR_id[1]]
                RR_embs.append(RR)

                
                if pq_index[1]==-1:
                    you_emb = self.weight.reshape(-1)
                else:
                    you_id =[int(pq_index[1]),int(pq_index[1]*100%100+0.5)-1]
                    you_emb = sample_i_mention_embings[you_id[0]][you_id[1]]
                You_embs.append(you_emb)

                
                h_id = [int(p_eid),int(p_eid*100%100+0.5)-1]
                h_emb = sample_i_mention_embings[h_id[0]][h_id[1]]
                H_emb.append(h_emb)


                
                duanyupos = [entity_pos[i][ int(pq_index[0][0])   ][int(pq_index[0][0]*100%100+0.5)-1][0],entity_pos[i][int(pq_index[0][1])   ][int(pq_index[0][1]*100%100+0.5)-1][1]]
                duanyu_emb = sequence_output[i,duanyupos[0]:duanyupos[1]].mean(0)
                Duanyu.append(duanyu_emb)

                
                
                head_w_pos = [int(pq_index[2]),int(pq_index[2]*100%100+0.5)-1]
                
                head_att=sample_i_mention_attention[head_w_pos[0]][head_w_pos[1]]
                
                this_w_pos = [int(p_eid),int(p_eid*100%100+0.5)-1]
                
                this_att = sample_i_mention_attention[this_w_pos[0]][this_w_pos[1]]
                
                
                tail_w_pos = [int(pq_index[3]),int(pq_index[3]*100%100+0.5)-1]
                
                tail_att=sample_i_mention_attention[tail_w_pos[0]][tail_w_pos[1]]

                hz_att = (head_att*this_att).reshape(1,-1)
                hz_pair =torch.mm(hz_att,sequence_output[i]).reshape(-1)
                NR1.append(hz_pair)
                hz_att = (tail_att * this_att).reshape(1, -1)
                hz_pair = torch.mm(hz_att, sequence_output[i]).reshape(-1)
                NR2.append(hz_pair)






            RR_embs = torch.stack(RR_embs, dim=0).cuda()
            You_embs = torch.stack(You_embs, dim=0).cuda()
            H_emb = torch.stack(H_emb, dim=0).cuda()
            part_a = torch.cat((RR_embs,You_embs,H_emb),dim=1)

            Duanyu = torch.stack(Duanyu, dim=0).cuda()
            NR1 = torch.stack(NR1, dim=0).cuda()
            NR2 = torch.stack(NR2, dim=0).cuda()
            


            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            hss.append(part_a)
            sss.append(Duanyu)
            N1.append(NR1)
            N2.append(NR2)
        hss = torch.cat(hss, dim=0)
        sss = torch.cat(sss, dim=0)
        N1 =  torch.cat(N1, dim=0)
        N2 = torch.cat(N2, dim=0)

        
        return hss, sss,N1,N2

    def forward(self,
                input_ids=None,
                attention_mask=None,
                labels=None,
                entity_pos=None,
                hts=None,
                instance_mask=None,
                index=None,
                title=None
                ):

        sequence_output, attention = self.encode(input_ids, attention_mask)
        hss, sss,N1,N2 = self.get_hrt(sequence_output, attention, entity_pos, hts,index)

        tensor_1 = self.A_linear(hss)
        tensor_2 = self.bilinear_rr(N1,N2)
        tensor_3 = self.liner2(sss)
        logits = self.end_linear(self.dp(torch.cat([tensor_1, tensor_2,tensor_3], dim=1)))

        
        
        
        
        
        
        


        
        
        
        
        
        
        return logits
