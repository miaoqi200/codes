import json
import random
dev = json.load(open("dataset/docred/dev.json"))
train = json.load(open("dataset/docred/train_annotated.json"))
for sample in dev:
    vertex = sample['vertexSet']
    for i in range(len(vertex)):
        if random.random()<0.1:
            # {'r': 'P607', 'h': 1, 't': 3, 'evidence': [0]}
            if i!=0:
                sample['labels'].append({'r': 'TH', 'h': 0, 't': i, 'evidence': []})
            else:
                sample['labels'].append({'r': 'TH', 'h': 1, 't': i, 'evidence': []})
for sample in train:
    vertex = sample['vertexSet']
    for i in range(len(vertex)):
        if random.random()<0.1:
            # {'r': 'P607', 'h': 1, 't': 3, 'evidence': [0]}
            if i!=0:
                sample['labels'].append({'r': 'TH', 'h': 0, 't': i, 'evidence': []})
            else:
                sample['labels'].append({'r': 'TH', 'h': 1, 't': i, 'evidence': []})

json.dump(dev,open("dataset/docred/devTH.json","w",encoding="utf8"))
json.dump(train,open("dataset/docred/train_annotatedTH.json","w",encoding="utf8"))
