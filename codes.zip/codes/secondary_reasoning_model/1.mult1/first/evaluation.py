import os
import os.path
import json
import numpy as np

rel2id = json.load(open('meta/rel2id.json', 'r'))
id2rel = {value: key for key, value in rel2id.items()}


def to_official(preds, features):
    h_idx, t_idx, vert_idx, title,labs = [], [], [], [],[]

    for f in features:
        labels = f['labels']
        hts = f["hts"]
        vert_idx += [ver[0] for ver in hts]
        # h_idx += [ht[0] for ht in hts]
        # t_idx += [ht[1] for ht in hts]
        title += [f["title"] for ht in hts]
        # labs += [f["title"] for ht in hts]

    res = []
    for i in range(preds.shape[0]):
        pred = preds[i]
        pred = np.nonzero(pred)[0].tolist()
        for p in pred:
            if p != 0:
                res.append(
                    {
                        'title': title[i],
                        # 'h_idx': h_idx[i],
                        # 't_idx': t_idx[i],
                        'ver_id': vert_idx[i] ,
                        'r': id2rel[p],
                    }
                )
    return res


def gen_train_facts(data_file_name, truth_dir):
    fact_file_name = data_file_name[data_file_name.find("train_"):]
    fact_file_name = os.path.join(truth_dir, fact_file_name.replace(".json", ".fact"))

    if os.path.exists(fact_file_name):
        fact_in_train = set([])
        triples = json.load(open(fact_file_name))
        for x in triples:
            fact_in_train.add(tuple(x))
        return fact_in_train

    fact_in_train = set([])
    ori_data = json.load(open(data_file_name))
    for data in ori_data:
        vertexSet = data['vertexSet']
        for label in data['labels']:
            rel = label['r']
            for n1 in vertexSet[label['t']]:
                fact_in_train.add((n1['name'], id2rel[1]))
            # for n1 in vertexSet[label['h']]:
            #     for n2 in vertexSet[label['t']]:
            #         fact_in_train.add((n1['name'], n2['name'], rel))

    json.dump(list(fact_in_train), open(fact_file_name, "w"))

    return fact_in_train
def gen_train_facts2(data_file_name, truth_dir, r_name):
    fact_file_name = data_file_name[data_file_name.find("train_"):]
    fact_file_name = os.path.join(truth_dir, fact_file_name.replace(".json", ".fact"))

    if os.path.exists(fact_file_name):
        fact_in_train = set([])
        triples = json.load(open(fact_file_name))
        for x in triples:
            fact_in_train.add(tuple(x))
        return fact_in_train

    fact_in_train = set([])
    ori_data = json.load(open(data_file_name))
    for data in ori_data:
        vertexSet = data['vertexSet']
        for label in data['labels']:
            rel = label['r']
            if rel==r_name:
                for n1 in vertexSet[label['t']]:
                    fact_in_train.add((n1['name'],id2rel[1]))
                # fact_in_train.add((n1['name'], n2['name'], rel))

            # for n1 in vertexSet[label['h']]:
            #     for n2 in vertexSet[label['t']]:
            #         fact_in_train.add((n1['name'], n2['name'], rel))

    json.dump(list(fact_in_train), open(fact_file_name, "w"))

    return fact_in_train

def official_evaluate(tmp, path,tag):
    '''
        Adapted from the official evaluation code
    '''
    if len(tmp)==0:
        return 0,{
        tag + "_F1": 0 * 100,
        tag + "_F1_acc": 0 * 100,
        tag + "_F1_recall": 0 * 100,
        tag + "_F1_Ign": 0 * 100,

    }



    truth_dir = os.path.join(path, 'ref')

    if not os.path.exists(truth_dir):
        os.makedirs(truth_dir)

    fact_in_train_annotated = gen_train_facts(os.path.join(path, "train_annotatedTH.json"), truth_dir)
    fact_in_train_distant = gen_train_facts(os.path.join(path, "train_distant.json"), truth_dir)

    if tag == "dev":
        truth = json.load(open(os.path.join(path, "devTH.json")))
    if tag == "train":
        truth = json.load(open(os.path.join(path, "train_annotatedTH.json")))



    std = {}
    tot_evidences = 1
    titleset = set([])

    title2vectexSet = {}
    qingdan_name = {}
    for sample in truth:
        if "labels" in sample:
            for label in sample['labels']:
                # if label['r'] == r_name:
                    for i in sample['vertexSet'][label['t']]:
                        if label['r'] not in qingdan_name:
                            qingdan_name[label['r']] = set()
                        qingdan_name[label['r']].add(i['name'])

    for x in truth:
        title = x['title']
        titleset.add(title)

        vertexSet = x['vertexSet']
        title2vectexSet[title] = vertexSet

        shouji_label = {}
        for i in range(len(vertexSet)):
            for ii in vertexSet[i]:
                for k,v in qingdan_name.items():
                    if ii['name'] in v:
                        if k not in shouji_label:
                            shouji_label[k]=set()
                        shouji_label[k].add(i)
        for label in x['labels']:
            r = label['r']
            # h_idx = label['h']
            t_idx = label['t']
            shouji_label[r].add(t_idx)
        for k,v in shouji_label.items():
            for i in v:
                std[(title, k, i)] = set([])
                tot_evidences += len([])


        # for label in x['labels']:
        #     r = label['r']
        #     h_idx = label['h']
        #     t_idx = label['t']
        #     std[(title, r, h_idx, t_idx)] = set(label['evidence'])
        #     tot_evidences += len(label['evidence'])

    # tot_relations = len(std)
    # tmp.sort(key=lambda x: (x['title'], x['h_idx'], x['t_idx'], x['r']))
    # submission_answer = [tmp[0]]
    # for i in range(1, len(tmp)):
    #     x = tmp[i]
    #     y = tmp[i - 1]
    #     if (x['title'], x['h_idx'], x['t_idx'], x['r']) != (y['title'], y['h_idx'], y['t_idx'], y['r']):
    #         submission_answer.append(tmp[i])
    tot_relations = len(std)
    tmp.sort(key=lambda x: (x['title'], x['ver_id'], x['r']))
    submission_answer = [tmp[0]]
    for i in range(1, len(tmp)):
        x = tmp[i]
        y = tmp[i - 1]
        if (x['title'], x['ver_id'], x['r']) != (y['title'], y['ver_id'], y['r']):
            submission_answer.append(tmp[i])

    correct_re = 0
    correct_evidence = 0
    pred_evi = 0

    correct_in_train_annotated = 0
    correct_in_train_distant = 0
    titleset2 = set([])
    for x in submission_answer:
        title = x['title']
        ver_id = x['ver_id']
        # h_idx = x['h_idx']
        # t_idx = x['t_idx']
        r = x['r']
        titleset2.add(title)
        if title not in title2vectexSet:
            continue
        vertexSet = title2vectexSet[title]

        if 'evidence' in x:
            evi = set(x['evidence'])
        else:
            evi = set([])
        pred_evi += len(evi)

        if (title, r, ver_id) in std:
            correct_re += 1
            stdevi = std[(title, r, ver_id)]
            correct_evidence += len(stdevi & evi)
            in_train_annotated = in_train_distant = False
            for n1 in vertexSet[ver_id]:
                if (n1['name'], r) in fact_in_train_annotated:
                    in_train_annotated = True
                if (n1['name'], r) in fact_in_train_distant:
                    in_train_distant = True

            if in_train_annotated:
                correct_in_train_annotated += 1
            if in_train_distant:
                correct_in_train_distant += 1

    re_p = 1.0 * correct_re / len(submission_answer)
    re_r = 1.0 * correct_re / tot_relations
    if re_p + re_r == 0:
        re_f1 = 0
    else:
        re_f1 = 2.0 * re_p * re_r / (re_p + re_r)

    evi_p = 1.0 * correct_evidence / pred_evi if pred_evi > 0 else 0
    evi_r = 1.0 * correct_evidence / tot_evidences
    if evi_p + evi_r == 0:
        evi_f1 = 0
    else:
        evi_f1 = 2.0 * evi_p * evi_r / (evi_p + evi_r)

    re_p_ignore_train_annotated = 1.0 * (correct_re - correct_in_train_annotated) / (len(submission_answer) - correct_in_train_annotated + 1e-5)
    re_p_ignore_train = 1.0 * (correct_re - correct_in_train_distant) / (len(submission_answer) - correct_in_train_distant + 1e-5)

    if re_p_ignore_train_annotated + re_r == 0:
        re_f1_ignore_train_annotated = 0
    else:
        re_f1_ignore_train_annotated = 2.0 * re_p_ignore_train_annotated * re_r / (re_p_ignore_train_annotated + re_r)

    if re_p_ignore_train + re_r == 0:
        re_f1_ignore_train = 0
    else:
        re_f1_ignore_train = 2.0 * re_p_ignore_train * re_r / (re_p_ignore_train + re_r)
    f1_acc, f1_recall = re_p, re_r


    # best_f1 = 0
    # best_f1_ign = 0
    # f1_acc, f1_recall = 0, 0
    # if len(ans) > 0:
    #     best_f1, _, best_f1_ign, _, f1_acc, f1_recall = official_evaluate(ans, args.data_dir, tag)
    output = {
        tag + "_F1": re_f1 * 100,
        tag + "_F1_acc": f1_acc * 100,
        tag + "_F1_recall": f1_recall * 100,
        tag + "_F1_Ign": re_f1_ignore_train_annotated * 100,

    }
    return re_f1, output
    # return re_f1, evi_f1, re_f1_ignore_train_annotated, re_f1_ignore_train, f1_acc, f1_recall

def t_evaluate(tmp1, path,r_name,tag):
    '''
        Adapted from the official evaluation code
    '''
    tmp = [i for i in tmp1 if i['r'] == r_name]
    if len(tmp)==0:
        return 0,{
        tag + "_F1": 0 * 100,
        tag + "_F1_acc": 0 * 100,
        tag + "_F1_recall": 0 * 100,
        tag + "_F1_Ign": 0 * 100,

    }

    truth_dir = os.path.join(path, 'ref')

    if not os.path.exists(truth_dir):
        os.makedirs(truth_dir)

    fact_in_train_annotated = gen_train_facts2(os.path.join(path, "train_annotatedTH.json"), truth_dir,r_name)
    fact_in_train_distant = gen_train_facts2(os.path.join(path, "train_distant.json"), truth_dir,r_name)
    if tag=="dev":
        truth = json.load(open(os.path.join(path, "devTH.json")))
    if tag=="train":
        truth = json.load(open(os.path.join(path, "train_annotatedTH.json")))

    std = {}
    tot_evidences = 1
    titleset = set([])

    title2vectexSet = {}
    manzutiaojian_name = set()
    for sample in truth:
        if "labels" in sample:
            for label in sample['labels']:
                if label['r'] == r_name:
                    for i in sample['vertexSet'][label['t']]:
                        manzutiaojian_name.add(i['name'])
    for x in truth:
        title = x['title']
        titleset.add(title)

        vertexSet = x['vertexSet']
        title2vectexSet[title] = vertexSet

        shouji_label = set()
        for i in range(len(vertexSet)):
            for ii in vertexSet[i]:
                if ii['name'] in manzutiaojian_name:
                    shouji_label.add(i)

        for label in x['labels']:
            r = label['r']
            if r!=r_name:
                continue
            # h_idx = label['h']
            t_idx = label['t']
            shouji_label.add(t_idx)
        for i in shouji_label:
            std[(title, r_name, i)] = set([])
            tot_evidences += len([])

    tot_relations = len(std)
    tmp.sort(key=lambda x: (x['title'], x['ver_id'], x['r']))
    submission_answer = [tmp[0]]
    for i in range(1, len(tmp)):
        x = tmp[i]
        y = tmp[i - 1]
        if (x['title'],  x['ver_id'], x['r']) != (y['title'],y['ver_id'], y['r']):
            submission_answer.append(tmp[i])

    correct_re = 0
    correct_evidence = 0
    pred_evi = 0

    correct_in_train_annotated = 0
    correct_in_train_distant = 0
    titleset2 = set([])
    for x in submission_answer:
        title = x['title']
        ver_id = x['ver_id']
        # h_idx = x['h_idx']
        # t_idx = x['t_idx']
        r = x['r']
        titleset2.add(title)
        if title not in title2vectexSet:
            continue
        vertexSet = title2vectexSet[title]

        if 'evidence' in x:
            evi = set(x['evidence'])
        else:
            evi = set([])
        pred_evi += len(evi)

        if (title, r, ver_id) in std:
            correct_re += 1
            stdevi = std[(title, r, ver_id)]
            correct_evidence += len(stdevi & evi)
            in_train_annotated = in_train_distant = False
            for n1 in vertexSet[ver_id]:
                    if (n1['name'], r) in fact_in_train_annotated:
                        in_train_annotated = True
                    if (n1['name'], r) in fact_in_train_distant:
                        in_train_distant = True

            if in_train_annotated:
                correct_in_train_annotated += 1
            if in_train_distant:
                correct_in_train_distant += 1

    re_p = 1.0 * correct_re / len(submission_answer)
    re_r = 1.0 * correct_re / tot_relations
    if re_p + re_r == 0:
        re_f1 = 0
    else:
        re_f1 = 2.0 * re_p * re_r / (re_p + re_r)

    evi_p = 1.0 * correct_evidence / pred_evi if pred_evi > 0 else 0
    evi_r = 1.0 * correct_evidence / tot_evidences
    if evi_p + evi_r == 0:
        evi_f1 = 0
    else:
        evi_f1 = 2.0 * evi_p * evi_r / (evi_p + evi_r)

    re_p_ignore_train_annotated = 1.0 * (correct_re - correct_in_train_annotated) / (len(submission_answer) - correct_in_train_annotated + 1e-5)
    re_p_ignore_train = 1.0 * (correct_re - correct_in_train_distant) / (len(submission_answer) - correct_in_train_distant + 1e-5)

    if re_p_ignore_train_annotated + re_r == 0:
        re_f1_ignore_train_annotated = 0
    else:
        re_f1_ignore_train_annotated = 2.0 * re_p_ignore_train_annotated * re_r / (re_p_ignore_train_annotated + re_r)

    if re_p_ignore_train + re_r == 0:
        re_f1_ignore_train = 0
    else:
        re_f1_ignore_train = 2.0 * re_p_ignore_train * re_r / (re_p_ignore_train + re_r)
    f1_acc, f1_recall = re_p,re_r

    output = {
        tag + "_F1": re_f1 * 100,
        tag + "_F1_acc": f1_acc * 100,
        tag + "_F1_recall": f1_recall * 100,
        tag + "_F1_Ign": re_f1_ignore_train_annotated * 100,

    }
    return re_f1, output
    # return re_f1, evi_f1, re_f1_ignore_train_annotated, re_f1_ignore_train, f1_acc,f1_recall

# def t_evaluate(tmp, path,tag,r_name):
#     tmp = [i for i in tmp if i['r'] == r_name]
#     truth_dir = os.path.join(path, 'ref')
#
#     if not os.path.exists(truth_dir):
#         os.makedirs(truth_dir)
#
#     fact_in_train_annotated = gen_train_facts(os.path.join(path, "train_annotated.json"), truth_dir)
#     fact_in_train_distant = gen_train_facts(os.path.join(path, "train_distant.json"), truth_dir)
#
#     if tag == "dev":
#         truth = json.load(open(os.path.join(path, "dev.json")))
#     if tag == "train":
#         truth = json.load(open(os.path.join(path, "train_annotated.json")))
#
#     std = {}
#     tot_evidences = 1
#     titleset = set([])
#
#     title2vectexSet = {}
#     qingdan_name = {}
#     for sample in truth:
#         if "labels" in sample:
#             for label in sample['labels']:
#                 # if label['r'] == r_name:
#                     for i in sample['vertexSet'][label['t']]:
#                         if label['r'] not in qingdan_name:
#                             qingdan_name[label['r']] = set()
#                         qingdan_name[label['r']].add(i['name'])
#
#     for x in truth:
#         title = x['title']
#         titleset.add(title)
#
#         vertexSet = x['vertexSet']
#         title2vectexSet[title] = vertexSet
#
#         shouji_label = {}
#         for i in range(len(vertexSet)):
#             for ii in vertexSet[i]:
#                 for k,v in qingdan_name.items():
#                     if ii['name'] in v:
#                         if k not in shouji_label:
#                             shouji_label[k]=set()
#                         shouji_label[k].add(i)
#         for label in x['labels']:
#             r = label['r']
#             # h_idx = label['h']
#             t_idx = label['t']
#             shouji_label[r].add(t_idx)
#         for k,v in shouji_label.items():
#             for i in v:
#                 std[(title, k, i)] = set([])
#                 tot_evidences += len([])
#
#
#         # for label in x['labels']:
#         #     r = label['r']
#         #     h_idx = label['h']
#         #     t_idx = label['t']
#         #     std[(title, r, h_idx, t_idx)] = set(label['evidence'])
#         #     tot_evidences += len(label['evidence'])
#
#     # tot_relations = len(std)
#     # tmp.sort(key=lambda x: (x['title'], x['h_idx'], x['t_idx'], x['r']))
#     # submission_answer = [tmp[0]]
#     # for i in range(1, len(tmp)):
#     #     x = tmp[i]
#     #     y = tmp[i - 1]
#     #     if (x['title'], x['h_idx'], x['t_idx'], x['r']) != (y['title'], y['h_idx'], y['t_idx'], y['r']):
#     #         submission_answer.append(tmp[i])
#     tot_relations = len(std)
#     tmp.sort(key=lambda x: (x['title'], x['ver_id'], x['r']))
#     submission_answer = [tmp[0]]
#     for i in range(1, len(tmp)):
#         x = tmp[i]
#         y = tmp[i - 1]
#         if (x['title'], x['ver_id'], x['r']) != (y['title'], y['ver_id'], y['r']):
#             submission_answer.append(tmp[i])
#
#     correct_re = 0
#     correct_evidence = 0
#     pred_evi = 0
#
#     correct_in_train_annotated = 0
#     correct_in_train_distant = 0
#     titleset2 = set([])
#     for x in submission_answer:
#         title = x['title']
#         ver_id = x['ver_id']
#         # h_idx = x['h_idx']
#         # t_idx = x['t_idx']
#         r = x['r']
#         titleset2.add(title)
#         if title not in title2vectexSet:
#             continue
#         vertexSet = title2vectexSet[title]
#
#         if 'evidence' in x:
#             evi = set(x['evidence'])
#         else:
#             evi = set([])
#         pred_evi += len(evi)
#
#         if (title, r, ver_id) in std:
#             correct_re += 1
#             stdevi = std[(title, r, ver_id)]
#             correct_evidence += len(stdevi & evi)
#             in_train_annotated = in_train_distant = False
#             for n1 in vertexSet[ver_id]:
#                 if (n1['name'], r) in fact_in_train_annotated:
#                     in_train_annotated = True
#                 if (n1['name'], r) in fact_in_train_distant:
#                     in_train_distant = True
#
#             if in_train_annotated:
#                 correct_in_train_annotated += 1
#             if in_train_distant:
#                 correct_in_train_distant += 1
#
#     re_p = 1.0 * correct_re / len(submission_answer)
#     re_r = 1.0 * correct_re / tot_relations
#     if re_p + re_r == 0:
#         re_f1 = 0
#     else:
#         re_f1 = 2.0 * re_p * re_r / (re_p + re_r)
#
#     evi_p = 1.0 * correct_evidence / pred_evi if pred_evi > 0 else 0
#     evi_r = 1.0 * correct_evidence / tot_evidences
#     if evi_p + evi_r == 0:
#         evi_f1 = 0
#     else:
#         evi_f1 = 2.0 * evi_p * evi_r / (evi_p + evi_r)
#
#     re_p_ignore_train_annotated = 1.0 * (correct_re - correct_in_train_annotated) / (len(submission_answer) - correct_in_train_annotated + 1e-5)
#     re_p_ignore_train = 1.0 * (correct_re - correct_in_train_distant) / (len(submission_answer) - correct_in_train_distant + 1e-5)
#
#     if re_p_ignore_train_annotated + re_r == 0:
#         re_f1_ignore_train_annotated = 0
#     else:
#         re_f1_ignore_train_annotated = 2.0 * re_p_ignore_train_annotated * re_r / (re_p_ignore_train_annotated + re_r)
#
#     if re_p_ignore_train + re_r == 0:
#         re_f1_ignore_train = 0
#     else:
#         re_f1_ignore_train = 2.0 * re_p_ignore_train * re_r / (re_p_ignore_train + re_r)
#     f1_acc, f1_recall = re_p, re_r
#     return re_f1, evi_f1, re_f1_ignore_train_annotated, re_f1_ignore_train, f1_acc, f1_recall
