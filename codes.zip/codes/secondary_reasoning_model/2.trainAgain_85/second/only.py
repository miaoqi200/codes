import json
import random
dev = json.load(open("dataset/docred/dev.json"))
train = json.load(open("dataset/docred/train_annotated.json"))
relchoose = json.load(open("meta/result.json"))
for sample in dev:
    labels = sample['labels']
    labels_ = []
    for i in labels:
        if i['r'] in relchoose:
            labels_.append(i)
    sample['labels'] = labels_

    # for i in range(len(vertex)):
    #     # if random.random()<0.1:
    #     #     # {'r': 'P607', 'h': 1, 't': 3, 'evidence': [0]}
    #     #     if i!=0:
    #     #         sample['labels'].append({'r': 'TH', 'h': 0, 't': i, 'evidence': []})
    #     #     else:
    #     #         sample['labels'].append({'r': 'TH', 'h': 1, 't': i, 'evidence': []})
for sample in train:
    labels = sample['labels']
    labels_ = []
    for i in labels:
        if i['r'] in relchoose:
            labels_.append(i)
    sample['labels'] = labels_




    # for i in range(len(vertex)):
    #     if random.random()<0.1:
    #         # {'r': 'P607', 'h': 1, 't': 3, 'evidence': [0]}
    #         if i!=0:
    #             sample['labels'].append({'r': 'TH', 'h': 0, 't': i, 'evidence': []})
    #         else:
    #             sample['labels'].append({'r': 'TH', 'h': 1, 't': i, 'evidence': []})

json.dump(dev,open("dataset/docred/dev_part.json","w",encoding="utf8"))
json.dump(train,open("dataset/docred/train_annotated_part.json","w",encoding="utf8"))
